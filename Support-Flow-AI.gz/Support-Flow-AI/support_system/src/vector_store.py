"""
FAISS vector store management.

Handles creation, persistence, similarity search, and incremental
document addition. All embedding calls go through OpenAIEmbeddings so
the same model is used consistently.
"""
import os

from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

from src.config import EMBEDDING_MODEL, VECTOR_STORE_PATH


def _get_embeddings() -> OpenAIEmbeddings:
    """Return an OpenAIEmbeddings instance using the configured model."""
    return OpenAIEmbeddings(model=EMBEDDING_MODEL)


def create_vector_store(documents: list[Document]) -> FAISS:
    """
    Build a new FAISS index from a list of Document chunks.
    Returns the in-memory FAISS store.
    """
    embeddings = _get_embeddings()
    store = FAISS.from_documents(documents, embeddings)
    return store


def save_vector_store(store: FAISS, path: str = VECTOR_STORE_PATH) -> None:
    """Persist the FAISS index to disk so it survives session restarts."""
    os.makedirs(path, exist_ok=True)
    store.save_local(path)


def load_vector_store(path: str = VECTOR_STORE_PATH) -> FAISS | None:
    """
    Load a previously saved FAISS index from disk.
    Returns None if no saved index exists.
    """
    index_file = os.path.join(path, "index.faiss")
    if not os.path.exists(index_file):
        return None

    embeddings = _get_embeddings()
    store = FAISS.load_local(
        path, embeddings, allow_dangerous_deserialization=True
    )
    return store


def add_documents(store: FAISS, documents: list[Document]) -> FAISS:
    """
    Merge new documents into an existing FAISS store.
    Returns the updated store (mutated in place but also returned for clarity).
    """
    embeddings = _get_embeddings()
    store.add_documents(documents)
    return store


def similarity_search(
    store: FAISS, query: str, k: int = 5
) -> list[tuple[Document, float]]:
    """
    Run a similarity search and return (Document, relevance_score) pairs.
    Scores are in [0, 1]; higher means more relevant.
    """
    results = store.similarity_search_with_relevance_scores(query, k=k)
    return results
