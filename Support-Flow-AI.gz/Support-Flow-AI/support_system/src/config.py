"""
Central configuration for the AI Support Workflow System.
All tunable parameters live here so nothing is hard-coded in business logic.
"""
import os

# ---------------------------------------------------------------------------
# OpenAI settings
# ---------------------------------------------------------------------------
OPENAI_API_KEY: str = os.environ.get("OPENAI_API_KEY", "")
CHAT_MODEL: str = "gpt-4o-mini"
EMBEDDING_MODEL: str = "text-embedding-3-small"

# ---------------------------------------------------------------------------
# Query validation
# ---------------------------------------------------------------------------
MAX_QUERY_LENGTH: int = 2000        # characters; longer queries are truncated
MIN_QUERY_LENGTH: int = 2           # characters; shorter queries are rejected

# ---------------------------------------------------------------------------
# RAG / retrieval settings
# ---------------------------------------------------------------------------
TOP_K_CHUNKS: int = 6          # chunks retrieved before MMR re-rank
MMR_LAMBDA: float = 0.65       # MMR diversity weight (0=diverse, 1=relevant)
MMR_FETCH_K: int = 12          # candidates fetched before MMR selection
MIN_RELEVANCE_SCORE: float = 0.25   # chunks below this are discarded
QUERY_EXPANSION_ENABLED: bool = True  # generate alternative query phrasings
QUERY_EXPANSION_COUNT: int = 2   # number of extra phrasings to generate
CHUNK_SIZE: int = 800
CHUNK_OVERLAP: int = 120

# ---------------------------------------------------------------------------
# Confidence scoring weights  (must sum to 1.0)
# ---------------------------------------------------------------------------
CONF_WEIGHT_RETRIEVAL: float = 0.50   # rank-weighted FAISS similarity
CONF_WEIGHT_TOP_SCORE: float = 0.20   # bonus for very high top-chunk score
CONF_WEIGHT_DENSITY: float = 0.30     # fraction of chunks above MIN_SCORE

CONF_COVERAGE_PENALTY: float = 0.30   # LLM signals it can't answer
CONF_BREVITY_PENALTY: float = 0.10    # suspiciously short response

# ---------------------------------------------------------------------------
# Escalation settings
# ---------------------------------------------------------------------------
DEFAULT_CONFIDENCE_THRESHOLD: float = 0.60

# SLA deadlines in hours per severity
ESCALATION_SLA_HOURS: dict = {
    "CRITICAL": 1,
    "HIGH": 4,
    "MEDIUM": 24,
    "LOW": 48,
}

# Maps severity → recommended human-agent action
ESCALATION_RECOMMENDED_ACTIONS: dict = {
    "CRITICAL": "Immediate review required. Contact customer within 1 hour. Loop in legal/security team if needed.",
    "HIGH":     "Prioritise this ticket. Respond within 4 hours with direct resolution or clear next steps.",
    "MEDIUM":   "Review and respond within 24 hours. Verify the policy facts and provide a grounded answer.",
    "LOW":      "Handle within 48 hours. AI confidence was borderline — validate the response before replying.",
}

# Keywords that trigger CRITICAL escalation (legal / security / physical threats)
CRITICAL_KEYWORDS: list[str] = [
    "lawsuit", "legal action", "attorney", "lawyer", "sue", "court",
    "report to authorities", "regulatory complaint", "data breach",
    "account hacked", "unauthorized access", "identity theft",
    # Physical threats
    "threatening", "physical harm", "going to hurt", "will hurt you",
    "going to harm", "kill you", "bomb", "shoot you", "death threat",
    "i will find you", "you will regret",
]

# Keywords that trigger HIGH escalation (strong dissatisfaction / financial risk)
HIGH_KEYWORDS: list[str] = [
    "fraud", "scam", "chargeback", "unauthorized charge",
    "dispute", "refund", "compensation", "account compromised",
    "harassment", "discrimination",
    # Strong abuse directed at the company (not physical threats)
    "piece of garbage", "piece of crap", "go to hell",
]

# Keywords that trigger at least MEDIUM escalation
MEDIUM_KEYWORDS: list[str] = [
    "frustrated", "angry", "unacceptable", "terrible", "worst",
    "cancel", "cancellation",
]

# Phrases that indicate the user explicitly wants a human
HUMAN_REQUEST_PHRASES: list[str] = [
    "speak to human", "talk to agent", "human agent", "real person",
    "live agent", "customer service rep", "speak to someone",
    "talk to a person", "human support", "real agent", "actual person",
]

# Kept for backward compat — resolved to CRITICAL+HIGH combined
SENSITIVE_KEYWORDS: list[str] = CRITICAL_KEYWORDS + HIGH_KEYWORDS

SENSITIVE_CATEGORIES: list[str] = ["Legal", "Complaint", "Security"]

# ---------------------------------------------------------------------------
# Retry / resilience settings
# ---------------------------------------------------------------------------
LLM_MAX_RETRIES: int = 3
LLM_RETRY_WAIT_SECONDS: float = 1.5

# ---------------------------------------------------------------------------
# Persistence paths
# ---------------------------------------------------------------------------
DATA_DIR: str = os.path.join(os.path.dirname(__file__), "..", "data")
VECTOR_STORE_PATH: str = os.path.join(DATA_DIR, "vector_store")
UPLOADS_PATH: str = os.path.join(DATA_DIR, "uploads")
DB_PATH: str = os.path.join(DATA_DIR, "interactions.db")
LOG_FILE: str = os.path.join(DATA_DIR, "app.log")

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT: str = """You are a professional customer support assistant. \
Your job is to answer customer questions accurately and helpfully using ONLY \
the information provided in the context below.

Rules you must follow:
1. Answer ONLY from the provided context. Do not make up information.
2. If the context does not contain enough information to fully answer the \
question, say exactly: "I don't have enough information in my knowledge base \
to answer this fully."
3. Always be polite, empathetic, and concise.
4. Cite sources naturally in your answer (e.g., "According to our policy…").
5. Never speculate, guess, or fabricate facts.
6. If the customer seems frustrated, acknowledge their feelings first before \
answering the question.
7. Structure longer answers with brief headers or bullet points for clarity.
"""
