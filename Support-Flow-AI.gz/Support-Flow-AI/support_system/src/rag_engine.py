"""
Enhanced RAG (Retrieval-Augmented Generation) engine.

Improvements over v1:
  - Query expansion: generate alternative phrasings and merge results
  - MMR retrieval: Maximum Marginal Relevance for diverse chunk selection
  - Min-score filtering: discard chunks below MIN_RELEVANCE_SCORE
  - Retry with exponential backoff on LLM calls
  - Full pipeline instrumentation via PipelineMetrics
  - Token usage tracking from API response
"""
import hashlib
import time
from typing import Optional

from openai import APIError, OpenAI, RateLimitError

from src.config import (
    CHAT_MODEL,
    LLM_MAX_RETRIES,
    LLM_RETRY_WAIT_SECONDS,
    MIN_RELEVANCE_SCORE,
    MMR_FETCH_K,
    MMR_LAMBDA,
    OPENAI_API_KEY,
    QUERY_EXPANSION_COUNT,
    QUERY_EXPANSION_ENABLED,
    SYSTEM_PROMPT,
    TOP_K_CHUNKS,
)
from src.confidence_scorer import score_response_detailed
from src.observability import PipelineMetrics, get_logger, timed_stage

logger = get_logger("rag_engine")

# ---------------------------------------------------------------------------
# LLM client with retry logic
# ---------------------------------------------------------------------------

def _llm_call(client: OpenAI, messages: list[dict], max_tokens: int = 1024, temp: float = 0.2):
    """
    Call the OpenAI chat API with exponential backoff on rate-limit / transient errors.
    Returns the raw completion object.
    """
    last_err: Optional[Exception] = None
    for attempt in range(1, LLM_MAX_RETRIES + 1):
        try:
            return client.chat.completions.create(
                model=CHAT_MODEL,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temp,
            )
        except RateLimitError as e:
            last_err = e
            wait = LLM_RETRY_WAIT_SECONDS * (2 ** (attempt - 1))
            logger.warning(f"Rate-limited (attempt {attempt}/{LLM_MAX_RETRIES}), waiting {wait}s")
            time.sleep(wait)
        except APIError as e:
            last_err = e
            if attempt == LLM_MAX_RETRIES:
                break
            time.sleep(LLM_RETRY_WAIT_SECONDS)

    raise RuntimeError(f"LLM call failed after {LLM_MAX_RETRIES} attempts: {last_err}")


# ---------------------------------------------------------------------------
# Query expansion
# ---------------------------------------------------------------------------

def _expand_query(client: OpenAI, query: str, n: int = QUERY_EXPANSION_COUNT) -> list[str]:
    """
    Generate `n` alternative phrasings of the query to improve retrieval recall.
    Returns a list of alternative queries (not including the original).
    Falls back to an empty list if expansion fails.
    """
    prompt = (
        f"Generate {n} short alternative phrasings of the following customer support query. "
        f"Each phrasing should capture the same intent but use different words. "
        f"Output one phrasing per line with no numbering, no explanations.\n\n"
        f"Query: {query}"
    )
    try:
        resp = _llm_call(
            client,
            [{"role": "user", "content": prompt}],
            max_tokens=150,
            temp=0.7,
        )
        raw = resp.choices[0].message.content.strip()
        alternatives = [line.strip() for line in raw.splitlines() if line.strip()]
        return alternatives[:n]
    except Exception as e:
        logger.warning(f"Query expansion failed, skipping: {e}")
        return []


# ---------------------------------------------------------------------------
# Retrieval with MMR and score filtering
# ---------------------------------------------------------------------------

def _retrieve_with_mmr(
    vector_store,
    query: str,
    k: int = TOP_K_CHUNKS,
) -> list[tuple]:
    """
    Retrieve chunks using MMR (Maximum Marginal Relevance) for diversity.
    Returns (Document, score) pairs, filtered by MIN_RELEVANCE_SCORE.
    """
    # MMR search returns Documents (no scores) — we retrieve scores separately
    # to support filtering. Strategy: fetch more than needed via similarity, then
    # apply MMR manually via LangChain's built-in method.
    try:
        # Get diverse docs via MMR
        mmr_docs = vector_store.max_marginal_relevance_search(
            query, k=k, fetch_k=MMR_FETCH_K, lambda_mult=MMR_LAMBDA
        )

        # Get the scores for those docs via a regular similarity search
        # so we can filter and report them
        scored_all = vector_store.similarity_search_with_relevance_scores(
            query, k=MMR_FETCH_K
        )

        # Build a lookup: content hash → score
        score_map: dict[str, float] = {}
        for doc, score in scored_all:
            h = hashlib.md5(doc.page_content[:200].encode()).hexdigest()
            score_map[h] = score

        # Match MMR docs to their scores
        result: list[tuple] = []
        for doc in mmr_docs:
            h = hashlib.md5(doc.page_content[:200].encode()).hexdigest()
            score = score_map.get(h, MIN_RELEVANCE_SCORE)
            if score >= MIN_RELEVANCE_SCORE:
                result.append((doc, score))

        return result

    except Exception:
        # Fallback to plain similarity search if MMR fails
        return [
            (doc, score)
            for doc, score in vector_store.similarity_search_with_relevance_scores(query, k=k)
            if score >= MIN_RELEVANCE_SCORE
        ]


def _multi_query_retrieve(
    vector_store,
    query: str,
    expansions: list[str],
    k: int = TOP_K_CHUNKS,
) -> list[tuple]:
    """
    Retrieve chunks for the original query + all expanded queries, deduplicate
    by content hash, keep the highest score per unique chunk.
    """
    seen: dict[str, tuple] = {}  # hash → (doc, score)

    all_queries = [query] + expansions
    per_query_k = max(3, k // len(all_queries) + 1)

    for q in all_queries:
        try:
            results = _retrieve_with_mmr(vector_store, q, k=per_query_k)
            for doc, score in results:
                h = hashlib.md5(doc.page_content[:200].encode()).hexdigest()
                if h not in seen or score > seen[h][1]:
                    seen[h] = (doc, score)
        except Exception as e:
            logger.warning(f"Retrieval failed for expansion query '{q[:40]}': {e}")

    # Sort by score descending, take top-k
    combined = sorted(seen.values(), key=lambda x: x[1], reverse=True)
    return combined[:k]


# ---------------------------------------------------------------------------
# Context block builder
# ---------------------------------------------------------------------------

def _build_context_block(docs_with_scores: list) -> tuple[str, list[dict], list[float]]:
    context_parts, sources, scores = [], [], []

    for i, (doc, score) in enumerate(docs_with_scores, start=1):
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", "")
        page_str = f", page {int(page) + 1}" if page != "" else ""

        # Trim very long chunks to avoid prompt bloat (~600 chars max)
        content = doc.page_content.strip()
        if len(content) > 700:
            content = content[:700] + "…"

        context_parts.append(f"[Source {i}: {source}{page_str}]\n{content}")
        sources.append({"source": source, "page": page, "score": round(score, 3)})
        scores.append(score)

    return "\n\n---\n\n".join(context_parts), sources, scores


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def generate_response(
    query: str,
    vector_store,
    conversation_history: list[dict],
    threshold: float = 0.60,
    metrics: Optional[PipelineMetrics] = None,
) -> dict:
    """
    Full RAG pipeline with observability instrumentation.

    Returns a dict with:
        response          (str)
        sources           (list[dict])
        confidence        (float)
        confidence_detail (dict)       — multi-dimensional breakdown
        retrieved_context (str)
        retrieval_scores  (list[float])
        no_docs_found     (bool)
        metrics           (PipelineMetrics)
    """
    if metrics is None:
        metrics = PipelineMetrics()

    client = OpenAI(api_key=OPENAI_API_KEY)
    pipeline_start = time.perf_counter()

    # ------------------------------------------------------------------ #
    # 1. Query expansion
    # ------------------------------------------------------------------ #
    expansions: list[str] = []
    if QUERY_EXPANSION_ENABLED:
        with timed_stage(metrics, "expansion"):
            expansions = _expand_query(client, query, QUERY_EXPANSION_COUNT)
            metrics.query_expanded = len(expansions) > 0
            if expansions:
                logger.debug("Query expansions generated", extra={
                    "original": query[:80], "expansions": expansions
                })

    # ------------------------------------------------------------------ #
    # 2. Retrieval (MMR + multi-query merge)
    # ------------------------------------------------------------------ #
    with timed_stage(metrics, "retrieval"):
        if expansions:
            docs_with_scores = _multi_query_retrieve(
                vector_store, query, expansions, k=TOP_K_CHUNKS
            )
        else:
            docs_with_scores = _retrieve_with_mmr(vector_store, query, k=TOP_K_CHUNKS)

    metrics.num_chunks_retrieved = len(docs_with_scores)
    metrics.update_retrieval_stats([s for _, s in docs_with_scores])

    if not docs_with_scores:
        metrics.total_ms = round((time.perf_counter() - pipeline_start) * 1000, 2)
        return {
            "response": (
                "I don't have enough information in my knowledge base to answer this. "
                "I'll escalate this to a human agent who can assist you further."
            ),
            "sources": [],
            "confidence": 0.0,
            "confidence_detail": {},
            "retrieved_context": "",
            "retrieval_scores": [],
            "no_docs_found": True,
            "metrics": metrics,
        }

    # ------------------------------------------------------------------ #
    # 3. Build context block
    # ------------------------------------------------------------------ #
    context_text, sources, scores = _build_context_block(docs_with_scores)

    # ------------------------------------------------------------------ #
    # 4. Construct LLM messages
    # ------------------------------------------------------------------ #
    context_prompt = (
        "Use ONLY the following context to answer the customer's question. "
        "If the answer is not fully covered by the context, say so explicitly.\n\n"
        f"=== CONTEXT START ===\n{context_text}\n=== CONTEXT END ===\n\n"
        f"Customer question: {query}"
    )

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(conversation_history)
    messages.append({"role": "user", "content": context_prompt})

    # ------------------------------------------------------------------ #
    # 5. LLM call
    # ------------------------------------------------------------------ #
    with timed_stage(metrics, "llm"):
        response_obj = _llm_call(client, messages, max_tokens=1024, temp=0.2)

    response_text = response_obj.choices[0].message.content.strip()

    # Track token usage
    if response_obj.usage:
        metrics.prompt_tokens = response_obj.usage.prompt_tokens
        metrics.completion_tokens = response_obj.usage.completion_tokens
        metrics.total_tokens = response_obj.usage.total_tokens

    # ------------------------------------------------------------------ #
    # 6. Confidence scoring
    # ------------------------------------------------------------------ #
    with timed_stage(metrics, "scoring"):
        conf_detail = score_response_detailed(scores, response_text)

    metrics.confidence_score = conf_detail["score"]
    metrics.confidence_breakdown = conf_detail

    # ------------------------------------------------------------------ #
    # 7. Finalise metrics
    # ------------------------------------------------------------------ #
    metrics.total_ms = round((time.perf_counter() - pipeline_start) * 1000, 2)
    metrics.log_summary(logger)

    return {
        "response": response_text,
        "sources": sources,
        "confidence": conf_detail["score"],
        "confidence_detail": conf_detail,
        "retrieved_context": context_text,
        "retrieval_scores": scores,
        "no_docs_found": False,
        "metrics": metrics,
    }


def generate_response_no_docs(
    query: str,
    conversation_history: list[dict],
    metrics: Optional[PipelineMetrics] = None,
) -> dict:
    """Fallback response when no knowledge base is loaded."""
    if metrics is None:
        metrics = PipelineMetrics()

    client = OpenAI(api_key=OPENAI_API_KEY)
    start = time.perf_counter()

    messages = [
        {
            "role": "system",
            "content": (
                "You are a customer support assistant. No knowledge base has been "
                "loaded yet. Politely let the customer know that the support team "
                "has not yet uploaded any documents, and advise them to try again "
                "later or contact support directly. Do NOT answer from general knowledge."
            ),
        },
        *conversation_history,
        {"role": "user", "content": query},
    ]

    with timed_stage(metrics, "llm"):
        response_obj = _llm_call(client, messages, max_tokens=300, temp=0.1)

    if response_obj.usage:
        metrics.total_tokens = response_obj.usage.total_tokens
        metrics.prompt_tokens = response_obj.usage.prompt_tokens
        metrics.completion_tokens = response_obj.usage.completion_tokens

    metrics.total_ms = round((time.perf_counter() - start) * 1000, 2)

    return {
        "response": response_obj.choices[0].message.content.strip(),
        "sources": [],
        "confidence": 0.0,
        "confidence_detail": {},
        "retrieved_context": "",
        "retrieval_scores": [],
        "no_docs_found": True,
        "metrics": metrics,
    }
