"""
Query classification module.

One LLM call does two things simultaneously:
  1. Categorises the query (General, Technical, Billing, …)
  2. Detects if the query is off-topic for a customer support system

Edge cases handled WITHOUT an LLM call (to save tokens and latency):
  - Pure greetings ("hi", "hello", "hey") → is_greeting=True
  - Very short / symbol-only queries (<3 chars) → is_too_short=True

Off-topic examples: general knowledge questions, jokes, math problems,
creative writing requests, weather, politics — anything unrelated to the
company's products, services, accounts, or policies.
"""
import json
import logging

from openai import OpenAI

from src.config import CHAT_MODEL, MAX_QUERY_LENGTH, OPENAI_API_KEY, SENSITIVE_CATEGORIES

_log = logging.getLogger(__name__)

CATEGORIES = [
    "General",    # Generic info / FAQ about products or services
    "Technical",  # Product bugs, how-to, troubleshooting
    "Billing",    # Payments, invoices, subscriptions
    "Account",    # Login, profile, permissions
    "Complaint",  # Dissatisfied customers
    "Legal",      # Regulatory, compliance, legal threats
    "Security",   # Account compromise, data breach
    "Other",      # Edge-case support queries that don't fit above
]

# ---------------------------------------------------------------------------
# Rule-based pre-checks (no LLM call needed)
# ---------------------------------------------------------------------------

_GREETING_WORDS: frozenset = frozenset([
    "hi", "hello", "hey", "hiya", "howdy", "sup", "yo",
    "good morning", "good afternoon", "good evening", "good day",
    "greetings", "what's up", "whats up", "morning", "evening",
    "afternoon",
])

_CLARIFY_RESPONSE: str = (
    "I didn't quite catch that — could you describe what you need help with? "
    "I'm here to assist with orders, billing, account issues, and technical problems."
)

_GREETING_RESPONSE: str = (
    "Hi there! I'm your customer support assistant.\n\n"
    "Here are some things I can help you with:\n"
    "- 📦 Orders, shipping, and returns\n"
    "- 💳 Billing, payments, and subscriptions\n"
    "- 🔧 Technical issues and troubleshooting\n"
    "- 👤 Account access and settings\n"
    "- 📜 Policies, warranties, and terms\n\n"
    "What can I help you with today?"
)


def _is_pure_greeting(query: str) -> bool:
    """Return True if the query is just a greeting with no support content."""
    normalized = query.lower().strip().rstrip("!.,?").strip()
    return normalized in _GREETING_WORDS


def _is_too_short(query: str) -> bool:
    """Return True for queries so short they convey no meaningful intent (0–1 chars)."""
    return len(query.strip()) < 2


# ---------------------------------------------------------------------------
# LLM-based classification prompt
# ---------------------------------------------------------------------------

_CLASSIFICATION_PROMPT = """You are a classifier for a customer support chat system.

Analyse the following customer query and return a JSON object with these fields:

1. "category": EXACTLY ONE of these support categories:
   {categories}
   Choose "Other" only if it is a real support query that does not fit the others.

2. "is_sensitive": true if the query involves legal threats, fraud, account breaches,
   or strong emotional distress. Otherwise false.

3. "is_off_topic": true if the query has NOTHING to do with customer support,
   products, services, accounts, orders, billing, or company policies.
   - OFF-TOPIC examples: "what is 2+2", "tell me a joke", "who is the president",
     "write me a poem", "what's the weather", "explain quantum physics",
     "what are the lottery numbers", "write code for me".
   - ON-TOPIC examples: "my order hasn't arrived", "how do I reset my password",
     "I want a refund", "your app keeps crashing", "I'm very angry about my bill",
     "can I speak to someone?", "my account was hacked".
   - When in doubt, treat as ON-TOPIC — it is always safer to attempt to help.

4. "reasoning": one sentence explaining your classification.

Return ONLY valid JSON — no markdown fences, no extra text.

Query: {query}
"""

# Shown to the user when their query is off-topic
_REDIRECT_TEMPLATE = (
    "That's a bit outside what I can help with — I'm a customer support "
    "assistant focused on questions about our products and services.\n\n"
    "Here are some things I **can** help you with:\n"
    "- 📦 Orders, shipping, and returns\n"
    "- 💳 Billing, payments, and subscriptions\n"
    "- 🔧 Technical issues and troubleshooting\n"
    "- 👤 Account access and settings\n"
    "- 📜 Policies, warranties, and terms\n\n"
    "Feel free to ask me anything along those lines!"
)

_REDIRECT_TEMPLATE_REPEATED = (
    "I've noticed a few questions that fall outside what I can help with here. "
    "I'm only set up to assist with questions about our products and services.\n\n"
    "If you're having trouble finding the right question or need general assistance, "
    "a human agent would be happy to help you directly. I'm flagging this for the team now."
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def classify_query(query: str) -> dict:
    """
    Classify a customer query.

    Performs fast rule-based checks first (greeting, too-short) before
    making an LLM call. Returns a dict with:
        category       (str)   — one of CATEGORIES
        is_sensitive   (bool)
        is_off_topic   (bool)  — true if unrelated to customer support
        is_greeting    (bool)  — true for pure greetings (no LLM call used)
        is_too_short   (bool)  — true for unintelligibly short queries
        redirect_msg   (str)   — message to show if off-topic (empty otherwise)
        reasoning      (str)
    """
    # ----------------------------------------------------------------
    # Rule-based fast-path: no LLM call needed
    # Greeting check runs FIRST so "hi"/"hey" (2 chars) are never
    # mistakenly flagged as too-short.
    # ----------------------------------------------------------------
    if _is_pure_greeting(query):
        return {
            "category": "General",
            "is_sensitive": False,
            "is_off_topic": False,
            "is_greeting": True,
            "is_too_short": False,
            "redirect_msg": "",
            "reasoning": "Pure greeting detected without support content.",
        }

    if _is_too_short(query):
        return {
            "category": "General",
            "is_sensitive": False,
            "is_off_topic": False,
            "is_greeting": False,
            "is_too_short": True,
            "redirect_msg": "",
            "reasoning": "Query too short to classify meaningfully.",
        }

    # ----------------------------------------------------------------
    # LLM classification (truncate first to protect token budget)
    # ----------------------------------------------------------------
    truncated = query[:MAX_QUERY_LENGTH]
    client = OpenAI(api_key=OPENAI_API_KEY)

    prompt = _CLASSIFICATION_PROMPT.format(
        categories=", ".join(CATEGORIES),
        query=truncated,
    )

    try:
        response = client.chat.completions.create(
            model=CHAT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=220,
        )
        raw = response.choices[0].message.content.strip()

        # Strip accidental markdown fences
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        result = json.loads(raw)

        if result.get("category") not in CATEGORIES:
            result["category"] = "Other"

        if result["category"] in SENSITIVE_CATEGORIES:
            result["is_sensitive"] = True

        result.setdefault("is_off_topic", False)
        result.setdefault("is_sensitive", False)
        result["is_greeting"] = False
        result["is_too_short"] = False
        result["redirect_msg"] = ""

        return result

    except Exception as exc:
        _log.error("classify_query failed: %s", exc, exc_info=True)
        return {
            "category": "Other",
            "is_sensitive": False,
            "is_off_topic": False,
            "is_greeting": False,
            "is_too_short": False,
            "redirect_msg": "",
            "reasoning": "Classification unavailable — defaulting to on-topic.",
        }


def get_redirect_message(streak: int) -> str:
    """
    Return the appropriate redirect message based on how many consecutive
    off-topic queries this session has seen.
      streak=1 → polite redirect
      streak≥2 → firmer redirect + escalation notice
    """
    if streak >= 2:
        return _REDIRECT_TEMPLATE_REPEATED
    return _REDIRECT_TEMPLATE


def get_greeting_response() -> str:
    """Return the standard greeting reply."""
    return _GREETING_RESPONSE


def get_clarify_response() -> str:
    """Return the clarification prompt for too-short queries."""
    return _CLARIFY_RESPONSE
