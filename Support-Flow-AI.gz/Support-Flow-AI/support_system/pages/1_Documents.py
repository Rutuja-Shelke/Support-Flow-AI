"""
Documents page — Upload and manage the knowledge base.

Users can:
  - Upload PDF or TXT/MD files
  - See which documents are already indexed
  - Clear the vector store and start fresh
"""
import sys
import os

import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.document_processor import process_uploaded_file
from src.vector_store import (
    create_vector_store,
    add_documents,
    save_vector_store,
    load_vector_store,
    VECTOR_STORE_PATH,
)
from src.interaction_logger import init_db
import shutil

init_db()

st.set_page_config(page_title="Documents — AI Support", page_icon="📚", layout="wide")

st.title("📚 Knowledge Base")
st.caption(
    "Upload your company documents here. The system will index them and use "
    "them to answer customer queries with source citations."
)

# ---- Ensure session state is in sync ----
if "vector_store" not in st.session_state:
    st.session_state.vector_store = load_vector_store()
if "doc_names" not in st.session_state:
    st.session_state.doc_names = []

# ---------------------------------------------------------------------------
# Upload section
# ---------------------------------------------------------------------------
st.subheader("Upload Documents")
st.info(
    "Supported formats: **PDF**, **TXT**, **MD**. "
    "You can upload multiple files at once. Each file is chunked and "
    "embedded into the FAISS vector index."
)

uploaded_files = st.file_uploader(
    "Choose files",
    type=["pdf", "txt", "md"],
    accept_multiple_files=True,
    label_visibility="collapsed",
)

if uploaded_files:
    if st.button("➕ Index selected files", type="primary", use_container_width=True):
        all_chunks = []
        results = []

        progress = st.progress(0, text="Processing files…")
        for i, uploaded_file in enumerate(uploaded_files):
            file_bytes = uploaded_file.read()
            chunks, msg = process_uploaded_file(file_bytes, uploaded_file.name)
            results.append((uploaded_file.name, msg, len(chunks)))
            all_chunks.extend(chunks)

            if uploaded_file.name not in st.session_state.doc_names:
                st.session_state.doc_names.append(uploaded_file.name)

            progress.progress((i + 1) / len(uploaded_files), text=f"Processing {uploaded_file.name}…")

        progress.empty()

        if all_chunks:
            with st.spinner("Building embeddings and updating vector index…"):
                if st.session_state.vector_store is None:
                    st.session_state.vector_store = create_vector_store(all_chunks)
                else:
                    st.session_state.vector_store = add_documents(
                        st.session_state.vector_store, all_chunks
                    )
                save_vector_store(st.session_state.vector_store)

            st.success(
                f"✅ Successfully indexed **{len(all_chunks)} chunks** "
                f"from {len(uploaded_files)} file(s). The chat page is now ready."
            )
        else:
            st.warning("No valid content was extracted from the uploaded files.")

        # Display per-file results
        st.subheader("Processing Results")
        for name, msg, count in results:
            if count > 0:
                st.success(f"**{name}** — {count} chunks")
            else:
                st.error(f"**{name}** — {msg}")

# ---------------------------------------------------------------------------
# Current index status
# ---------------------------------------------------------------------------
st.divider()
st.subheader("Current Knowledge Base")

if st.session_state.vector_store is not None:
    col1, col2 = st.columns([3, 1])
    with col1:
        if st.session_state.doc_names:
            st.write(f"**{len(st.session_state.doc_names)} document(s) indexed:**")
            for name in st.session_state.doc_names:
                st.markdown(f"- 📄 {name}")
        else:
            st.info("Documents are indexed but session names were cleared. Reload to see them.")

    with col2:
        if st.button("🗑️ Clear entire knowledge base", type="secondary"):
            if os.path.exists(VECTOR_STORE_PATH):
                shutil.rmtree(VECTOR_STORE_PATH)
            st.session_state.vector_store = None
            st.session_state.doc_names = []
            st.success("Knowledge base cleared.")
            st.rerun()
else:
    st.warning(
        "No documents indexed yet. Upload files above to build the knowledge base."
    )

# ---------------------------------------------------------------------------
# Tips
# ---------------------------------------------------------------------------
st.divider()
with st.expander("📋 Tips for best results"):
    st.markdown("""
    - **Chunk quality matters** — clean, well-structured documents produce better retrieval.
    - **Use text-based PDFs** — scanned PDFs without OCR may produce garbled text.
    - **Cover your FAQ topics** — include policy documents, product guides, and troubleshooting manuals.
    - **Re-upload if you update a document** — the system appends new chunks; it does not replace old ones.
    - **Confidence threshold** — tune it in the sidebar on the Chat page. Higher = stricter escalation.
    """)
