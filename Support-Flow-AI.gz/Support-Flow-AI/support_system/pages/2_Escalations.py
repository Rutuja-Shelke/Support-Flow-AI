"""
Escalations page — priority-sorted, SLA-tracked human-agent queue.

Improvements v2:
  - Sorted by priority (CRITICAL first, then HIGH, MEDIUM, LOW)
  - SLA countdown on every open ticket
  - Severity colour badge
  - Recommended action from escalation engine
  - Overdue tickets highlighted
"""
import os
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.interaction_logger import (
    init_db,
    get_all_escalations,
    update_escalation_status,
    get_stats,
)
from src.escalation_handler import SEVERITY_COLORS, sla_remaining

init_db()

st.set_page_config(page_title="Escalations — AI Support", page_icon="🚨", layout="wide")

st.title("🚨 Escalation Queue")
st.caption(
    "Queries escalated by the AI are listed here, ordered by severity. "
    "CRITICAL tickets must be actioned within 1 hour."
)

# ---------------------------------------------------------------------------
# Stats row
# ---------------------------------------------------------------------------
stats = get_stats()
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total Escalations", stats["escalated"])
c2.metric("Open", stats["open_escalations"])
c3.metric("🔴 Critical", stats.get("sev_critical", 0))
c4.metric("🟠 High", stats.get("sev_high", 0))
c5.metric("🟡 Medium + 🔵 Low", stats.get("sev_medium", 0) + stats.get("sev_low", 0))

st.divider()

# ---------------------------------------------------------------------------
# Load and filter
# ---------------------------------------------------------------------------
escalations = get_all_escalations(limit=500)

if not escalations:
    st.success("🎉 No escalations yet — the AI is handling all queries!")
    st.stop()

col_f1, col_f2 = st.columns(2)
status_filter = col_f1.selectbox(
    "Filter by status", ["All open", "open", "in_progress", "resolved", "All"]
)
sev_filter = col_f2.selectbox(
    "Filter by severity", ["All", "CRITICAL", "HIGH", "MEDIUM", "LOW", "Unclassified"]
)

filtered = escalations

if status_filter == "All open":
    filtered = [e for e in filtered if e["status"] != "resolved"]
elif status_filter != "All":
    filtered = [e for e in filtered if e["status"] == status_filter]

if sev_filter != "All":
    if sev_filter == "Unclassified":
        filtered = [e for e in filtered if not e.get("severity")]
    else:
        filtered = [e for e in filtered if e.get("severity") == sev_filter]

if not filtered:
    st.info(f"No escalations match the selected filters.")
    st.stop()

st.write(f"Showing **{len(filtered)}** ticket(s).")

# ---------------------------------------------------------------------------
# Severity badge helper
# ---------------------------------------------------------------------------
STATUS_LABELS = {
    "open": ("🔴 Open", "error"),
    "in_progress": ("🟡 In Progress", "warning"),
    "resolved": ("🟢 Resolved", "success"),
}

def _sev_badge(sev: str | None) -> str:
    if not sev:
        return "⚪ Unknown"
    return f"{SEVERITY_COLORS.get(sev, '⚠️')} {sev}"

# ---------------------------------------------------------------------------
# Render tickets
# ---------------------------------------------------------------------------
for esc in filtered:
    sev = esc.get("severity") or "—"
    status = esc.get("status", "open")
    status_label, _ = STATUS_LABELS.get(status, ("⚪ " + status, "info"))

    sla = ""
    if esc.get("sla_deadline") and status != "resolved":
        sla = f" | SLA: {sla_remaining(esc['sla_deadline'])}"

    header = (
        f"{_sev_badge(esc.get('severity'))} | "
        f"Ticket #{esc['id']} | {status_label}{sla} | {esc['timestamp'][:16]}"
    )

    # Auto-expand CRITICAL and overdue tickets
    auto_expand = sev == "CRITICAL" or (
        esc.get("sla_deadline") and "Overdue" in sla_remaining(esc.get("sla_deadline", ""))
        and status != "resolved"
    )

    with st.expander(header, expanded=auto_expand):

        # ---- Query and reasons ----
        st.markdown(f"**Customer Query:**\n\n> {esc['query']}")

        if esc.get("reasons"):
            st.markdown("**Escalation Reasons:**")
            for reason in esc["reasons"].split(";"):
                st.markdown(f"- {reason.strip()}")

        # ---- Recommended action ----
        if esc.get("recommended_action"):
            st.info(f"💡 **Recommended Action:** {esc['recommended_action']}")

        # ---- SLA status ----
        if esc.get("sla_deadline") and status != "resolved":
            remaining = sla_remaining(esc["sla_deadline"])
            sla_hours = {
                "CRITICAL": 1, "HIGH": 4, "MEDIUM": 24, "LOW": 48
            }.get(sev, "—")
            st.caption(f"SLA: {sla_hours}h window | {remaining} | Deadline: {esc['sla_deadline'][:16]} UTC")

        # ---- Agent notes ----
        if esc.get("agent_notes"):
            st.success(f"**Agent Notes:** {esc['agent_notes']}")

        st.divider()

        # ---- Action form ----
        col_status, col_notes = st.columns([1, 2])
        current_status_idx = ["open", "in_progress", "resolved"].index(status) if status in ["open", "in_progress", "resolved"] else 0
        new_status = col_status.selectbox(
            "Update Status",
            options=["open", "in_progress", "resolved"],
            index=current_status_idx,
            key=f"status_{esc['id']}",
        )
        new_notes = col_notes.text_input(
            "Agent Notes",
            value=esc.get("agent_notes") or "",
            key=f"notes_{esc['id']}",
            placeholder="Resolution notes, case ID, next steps…",
        )

        btn_type = "primary" if status != "resolved" else "secondary"
        if st.button("💾 Save changes", key=f"save_{esc['id']}", type=btn_type):
            update_escalation_status(esc["id"], new_status, new_notes)
            st.success(f"Ticket #{esc['id']} → **{new_status}**")
            st.rerun()

# ---------------------------------------------------------------------------
# Priority summary table
# ---------------------------------------------------------------------------
st.divider()
st.subheader("Summary Table")

df_data = []
for e in filtered:
    sla_str = sla_remaining(e["sla_deadline"]) if e.get("sla_deadline") and e.get("status") != "resolved" else "—"
    df_data.append({
        "ID": e["id"],
        "Severity": _sev_badge(e.get("severity")),
        "Status": e.get("status", "—"),
        "SLA": sla_str,
        "Query": (e["query"] or "")[:60] + ("…" if len(e.get("query","")) > 60 else ""),
        "Timestamp": (e["timestamp"] or "")[:16],
    })

if df_data:
    st.dataframe(pd.DataFrame(df_data), use_container_width=True, hide_index=True)

# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------
st.divider()
if st.button("📥 Export escalations as CSV"):
    df = pd.DataFrame(escalations)
    st.download_button(
        "Download CSV",
        data=df.to_csv(index=False),
        file_name="escalations.csv",
        mime="text/csv",
    )
