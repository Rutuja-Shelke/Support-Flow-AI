"""
Interaction Logs + Observability Dashboard.

Tabs:
  1. Interaction Log     — searchable, filterable table + deep-dive inspector
  2. Performance Metrics — latency charts, token usage, confidence distribution
  3. Escalation Analysis — escalation rate trends, severity breakdown
"""
import json
import os
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.interaction_logger import (
    init_db,
    get_all_interactions,
    get_stats,
    get_latency_series,
    get_confidence_series,
)
from src.observability import get_perf_stats

init_db()

st.set_page_config(page_title="Logs & Observability — AI Support", page_icon="📋", layout="wide")

st.title("📋 Logs & Observability")
st.caption("Full audit trail, performance metrics, and escalation analytics.")

# ---------------------------------------------------------------------------
# Stats bar
# ---------------------------------------------------------------------------
stats = get_stats()
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total Interactions", stats["total"])
c2.metric("Escalation Rate", f"{stats['escalated']/max(stats['total'],1):.0%}")
c3.metric("👍 Helpful %", f"{stats['helpful']/max(stats['total'],1):.0%}")
c4.metric("Avg Confidence", f"{stats.get('avg_confidence', 0):.0%}")
c5.metric("Avg Latency", f"{stats.get('avg_latency_ms', 0):.0f} ms")

st.divider()

tab_log, tab_perf, tab_esc = st.tabs(["📋 Interaction Log", "⚡ Performance", "📊 Escalation Analysis"])

# ===========================================================================
# TAB 1 — Interaction Log
# ===========================================================================
with tab_log:
    interactions = get_all_interactions(limit=500)

    if not interactions:
        st.info("No interactions logged yet. Start chatting on the Chat page.")
        st.stop()

    # Filters
    col_f1, col_f2, col_f3, col_f4 = st.columns(4)
    esc_filter = col_f1.selectbox("Escalated", ["All", "Yes", "No"])
    fb_filter = col_f2.selectbox("Feedback", ["All", "Helpful", "Not Helpful", "No Feedback"])
    qt_filter = col_f3.selectbox(
        "Query Type",
        ["All"] + sorted({i["query_type"] for i in interactions if i.get("query_type")}),
    )
    sev_filter = col_f4.selectbox(
        "Severity",
        ["All", "CRITICAL", "HIGH", "MEDIUM", "LOW", "None"],
    )

    filtered = interactions
    if esc_filter == "Yes":
        filtered = [i for i in filtered if i.get("escalated")]
    elif esc_filter == "No":
        filtered = [i for i in filtered if not i.get("escalated")]
    if fb_filter == "Helpful":
        filtered = [i for i in filtered if i.get("feedback") == "helpful"]
    elif fb_filter == "Not Helpful":
        filtered = [i for i in filtered if i.get("feedback") == "not_helpful"]
    elif fb_filter == "No Feedback":
        filtered = [i for i in filtered if not i.get("feedback")]
    if qt_filter != "All":
        filtered = [i for i in filtered if i.get("query_type") == qt_filter]
    if sev_filter != "All":
        if sev_filter == "None":
            filtered = [i for i in filtered if not i.get("severity")]
        else:
            filtered = [i for i in filtered if i.get("severity") == sev_filter]

    st.write(f"Showing **{len(filtered)}** interaction(s).")

    if filtered:
        df = pd.DataFrame(filtered)[[
            "id", "timestamp", "query_type", "severity", "confidence_score",
            "escalated", "feedback", "total_latency_ms", "total_tokens", "query"
        ]].copy()

        df["confidence_score"] = df["confidence_score"].apply(
            lambda x: f"{x:.0%}" if x is not None else "—"
        )
        df["escalated"] = df["escalated"].apply(lambda x: "⚠️ Yes" if x else "✓ No")
        df["feedback"] = df["feedback"].apply(
            lambda x: "👍" if x == "helpful" else ("👎" if x == "not_helpful" else "—")
        )
        df["total_latency_ms"] = df["total_latency_ms"].apply(
            lambda x: f"{x:.0f} ms" if x else "—"
        )
        df["total_tokens"] = df["total_tokens"].apply(lambda x: x if x else "—")
        df["query"] = df["query"].apply(lambda x: (x[:70] + "…") if x and len(x) > 70 else x)
        df["severity"] = df["severity"].fillna("—")

        df.columns = ["ID", "Timestamp", "Type", "Severity", "Confidence",
                      "Escalated", "Feedback", "Latency", "Tokens", "Query"]
        st.dataframe(df, use_container_width=True, hide_index=True)

    # Deep-dive inspector
    st.divider()
    st.subheader("🔍 Inspect Interaction")
    ids = ["—"] + [str(i["id"]) for i in filtered]
    sel_id = st.selectbox("Select interaction ID", ids)

    if sel_id != "—":
        rec = next((i for i in filtered if str(i["id"]) == sel_id), None)
        if rec:
            st.markdown(f"**Query:** {rec['query']}")
            st.markdown(f"**Response:**\n\n{rec['response']}")

            cols = st.columns(5)
            cols[0].metric("Confidence", f"{rec['confidence_score']:.0%}" if rec['confidence_score'] else "—")
            cols[1].metric("Type", rec.get("query_type") or "—")
            cols[2].metric("Severity", rec.get("severity") or "—")
            cols[3].metric("Latency", f"{rec['total_latency_ms']:.0f} ms" if rec.get("total_latency_ms") else "—")
            cols[4].metric("Tokens", rec.get("total_tokens") or "—")

            if rec.get("escalated"):
                st.error(f"⚠️ Escalated: {rec.get('escalation_reason', '—')}")

            # Confidence breakdown
            if rec.get("confidence_detail"):
                try:
                    cd = json.loads(rec["confidence_detail"]) if isinstance(rec["confidence_detail"], str) else rec["confidence_detail"]
                    with st.expander("🔬 Confidence breakdown"):
                        st.code(cd.get("breakdown", "—"), language=None)
                        bc = st.columns(3)
                        bc[0].metric("Retrieval", f"{cd.get('retrieval', 0):.0%}")
                        bc[1].metric("Top-score", f"{cd.get('top_score', 0):.0%}")
                        bc[2].metric("Density", f"{cd.get('density', 0):.0%}")
                except Exception:
                    pass

            if rec.get("retrieved_context"):
                with st.expander("📄 Retrieved context sent to LLM"):
                    st.text(rec["retrieved_context"])

            if rec.get("sources"):
                try:
                    with st.expander("📚 Source citations"):
                        for s in json.loads(rec["sources"]):
                            page_info = f", page {int(s['page']) + 1}" if s.get("page", "") != "" else ""
                            st.markdown(f"- **{s['source']}{page_info}** — {s.get('score', 0):.0%}")
                except Exception:
                    pass

    st.divider()
    if filtered and st.button("📥 Export log as CSV"):
        df_e = pd.DataFrame(filtered).drop(columns=["retrieved_context"], errors="ignore")
        st.download_button("Download CSV", df_e.to_csv(index=False), "interaction_logs.csv", "text/csv")


# ===========================================================================
# TAB 2 — Performance Metrics
# ===========================================================================
with tab_perf:
    perf = get_perf_stats()
    latencies = get_latency_series(limit=100)
    conf_series = get_confidence_series(limit=100)

    if not latencies and not conf_series:
        st.info("Performance data will appear after the first interactions.")
    else:
        # Latency percentiles
        st.subheader("Latency Percentiles")
        pc1, pc2, pc3, pc4 = st.columns(4)
        pc1.metric("p50 (median)", f"{perf.get('p50_ms', 0):.0f} ms")
        pc2.metric("p95", f"{perf.get('p95_ms', 0):.0f} ms")
        pc3.metric("p99", f"{perf.get('p99_ms', 0):.0f} ms")
        pc4.metric("Average", f"{perf.get('avg_ms', 0):.0f} ms")

        # Latency time series chart
        if latencies:
            st.subheader("End-to-End Latency Over Time")
            lat_df = pd.DataFrame(latencies)
            lat_df["timestamp"] = pd.to_datetime(lat_df["timestamp"])
            lat_df = lat_df.rename(columns={
                "total_latency_ms": "Total",
                "retrieval_latency_ms": "Retrieval",
                "llm_latency_ms": "LLM",
            })
            st.line_chart(lat_df.set_index("timestamp")[["Total", "Retrieval", "LLM"]])

        st.divider()

        # Token usage
        st.subheader("Token Usage")
        tc1, tc2, tc3 = st.columns(3)
        tc1.metric("Total Prompt Tokens", f"{perf.get('total_prompt_tokens', 0):,}")
        tc2.metric("Total Completion Tokens", f"{perf.get('total_completion_tokens', 0):,}")
        tc3.metric("Avg Tokens / Query", f"{perf.get('avg_tokens_per_query', 0):.0f}")

        st.divider()

        # Confidence distribution
        st.subheader("Confidence Score Distribution")
        if conf_series:
            cd1, cd2, cd3 = st.columns(3)
            cd1.metric("🟢 High (≥80%)", perf.get("conf_high", 0))
            cd2.metric("🟡 Medium (50–80%)", perf.get("conf_medium", 0))
            cd3.metric("🔴 Low (<50%)", perf.get("conf_low", 0))

            conf_df = pd.DataFrame({"confidence": conf_series})
            import numpy as np
            bins = np.arange(0, 1.05, 0.05)
            hist, edges = np.histogram(conf_df["confidence"], bins=bins)
            hist_df = pd.DataFrame({
                "bucket": [f"{e:.0%}" for e in edges[:-1]],
                "count": hist,
            }).set_index("bucket")
            st.bar_chart(hist_df)

        st.divider()
        st.subheader("Retrieval Quality")
        avg_chunks = perf.get("avg_chunks", 0)
        st.metric("Avg Chunks Retrieved per Query", f"{avg_chunks:.1f}")
        st.caption(
            "Higher chunk counts indicate broader document coverage. "
            "Low counts (<2) may indicate sparse knowledge base coverage."
        )


# ===========================================================================
# TAB 3 — Escalation Analysis
# ===========================================================================
with tab_esc:
    interactions_all = get_all_interactions(limit=500)

    if not interactions_all:
        st.info("No data yet.")
    else:
        st.subheader("Escalation Rate by Query Type")

        type_stats: dict[str, dict] = {}
        for row in interactions_all:
            qt = row.get("query_type") or "Other"
            if qt not in type_stats:
                type_stats[qt] = {"total": 0, "escalated": 0}
            type_stats[qt]["total"] += 1
            if row.get("escalated"):
                type_stats[qt]["escalated"] += 1

        rows_data = []
        for qt, s in sorted(type_stats.items()):
            rate = s["escalated"] / s["total"] if s["total"] else 0
            rows_data.append({
                "Query Type": qt,
                "Total": s["total"],
                "Escalated": s["escalated"],
                "Escalation Rate": f"{rate:.0%}",
            })
        if rows_data:
            st.dataframe(pd.DataFrame(rows_data), use_container_width=True, hide_index=True)

        st.divider()
        st.subheader("Severity Distribution (all time)")

        sev_counts: dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for row in interactions_all:
            s = row.get("severity")
            if s in sev_counts:
                sev_counts[s] += 1

        sv1, sv2, sv3, sv4 = st.columns(4)
        sv1.metric("🔴 CRITICAL", sev_counts["CRITICAL"])
        sv2.metric("🟠 HIGH", sev_counts["HIGH"])
        sv3.metric("🟡 MEDIUM", sev_counts["MEDIUM"])
        sv4.metric("🔵 LOW", sev_counts["LOW"])

        if any(sev_counts.values()):
            sev_df = pd.DataFrame(
                {"count": sev_counts}, index=list(sev_counts.keys())
            )
            st.bar_chart(sev_df)

        st.divider()
        st.subheader("Escalation Triggers (most common reasons)")

        reason_counts: dict[str, int] = {}
        for row in interactions_all:
            if row.get("escalation_reason"):
                for part in row["escalation_reason"].split(";"):
                    part = part.strip()
                    if part:
                        # Bucket into trigger type
                        if "confidence" in part.lower():
                            bucket = "Low confidence"
                        elif "keyword" in part.lower():
                            bucket = "Sensitive keyword"
                        elif "human" in part.lower() or "agent" in part.lower():
                            bucket = "Human requested"
                        elif "category" in part.lower() or "classified" in part.lower():
                            bucket = "Sensitive category"
                        elif "no relevant" in part.lower():
                            bucket = "No docs found"
                        else:
                            bucket = "Other"
                        reason_counts[bucket] = reason_counts.get(bucket, 0) + 1

        if reason_counts:
            rc_df = pd.DataFrame(
                {"count": reason_counts}, index=list(reason_counts.keys())
            ).sort_values("count", ascending=False)
            st.bar_chart(rc_df)
        else:
            st.info("No escalation trigger data yet.")
