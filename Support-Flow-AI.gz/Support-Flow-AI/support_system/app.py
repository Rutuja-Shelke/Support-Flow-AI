"""
AI-Powered Customer Support Workflow System — Main Chat Page
"""
import os
import sys
import uuid

import streamlit as st

sys.path.insert(0, os.path.dirname(__file__))

from src import config
from src.interaction_logger import init_db, log_interaction, update_feedback, get_stats
from src.vector_store import load_vector_store
from src.rag_engine import generate_response, generate_response_no_docs
from src.classifier import (
    classify_query,
    get_redirect_message,
    get_greeting_response,
    get_clarify_response,
)
from src.escalation_handler import determine_escalation, sla_deadline, SEVERITY_COLORS
from src.memory_manager import init_history, add_turn, format_for_prompt, clear_history
from src.confidence_scorer import confidence_label
from src.observability import PipelineMetrics, get_logger, timed_stage

logger = get_logger("app")

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI Support System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_db()

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "session_id" not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
if "messages" not in st.session_state:
    st.session_state.messages = []
if "history" not in st.session_state:
    st.session_state.history = init_history()
if "vector_store" not in st.session_state:
    st.session_state.vector_store = load_vector_store()
if "doc_names" not in st.session_state:
    st.session_state.doc_names = []
# Counts consecutive off-topic queries; resets on any on-topic query or clear
if "off_topic_streak" not in st.session_state:
    st.session_state.off_topic_streak = 0

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("🤖 AI Support System")
    st.caption("Enterprise Customer Support Workflow")
    st.divider()

    threshold = st.slider(
        "Confidence Threshold",
        min_value=0.30,
        max_value=0.90,
        value=config.DEFAULT_CONFIDENCE_THRESHOLD,
        step=0.05,
        help=(
            "Responses below this score are escalated. "
            "Higher = stricter. Try 0.75+ for sensitive domains."
        ),
        format="%.2f",
    )

    st.divider()
    st.subheader("Knowledge Base")
    if st.session_state.vector_store is not None:
        st.success("Documents loaded ✓")
        if st.session_state.doc_names:
            for name in st.session_state.doc_names:
                st.caption(f"📄 {name}")
    else:
        st.warning("No documents loaded.\nUpload on the **Documents** page.")

    st.divider()
    st.subheader("Session Stats")
    stats = get_stats()
    c1, c2 = st.columns(2)
    c1.metric("Total Queries", stats["total"])
    c2.metric("Open Escalations", stats["open_escalations"], delta_color="inverse")
    c1.metric("👍 Helpful", stats["helpful"])
    c2.metric("👎 Not helpful", stats["not_helpful"])

    if stats.get("avg_latency_ms", 0) > 0:
        st.caption(f"Avg latency: **{stats['avg_latency_ms']:.0f} ms**")
    if stats.get("avg_confidence", 0) > 0:
        st.caption(f"Avg confidence: **{stats['avg_confidence']:.0%}**")

    sev_open = [
        ("🔴 CRITICAL", stats.get("sev_critical", 0)),
        ("🟠 HIGH", stats.get("sev_high", 0)),
        ("🟡 MEDIUM", stats.get("sev_medium", 0)),
        ("🔵 LOW", stats.get("sev_low", 0)),
    ]
    if any(v > 0 for _, v in sev_open):
        st.caption("**Open by severity:**")
        for label, count in sev_open:
            if count:
                st.caption(f"  {label}: {count}")

    st.divider()
    if st.button("🗑️ Clear conversation", use_container_width=True):
        st.session_state.messages = []
        st.session_state.history = clear_history()
        st.session_state.off_topic_streak = 0   # FIX: reset streak on clear
        st.rerun()
    if st.button("🔄 Reload knowledge base", use_container_width=True):
        st.session_state.vector_store = load_vector_store()
        st.rerun()

# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
st.title("Customer Support Chat")
st.caption(
    "Ask your question below. Responses are grounded in company documents. "
    "Uncertain or sensitive queries are automatically escalated to a human agent."
)

# ---------------------------------------------------------------------------
# Helpers for rendering assistant messages from history
# ---------------------------------------------------------------------------

def _render_assistant_meta(msg: dict) -> None:
    """Render metadata badges/expanders for a stored assistant message."""
    tag = msg.get("msg_type", "rag")  # greeting | clarify | off_topic | rag

    # Greeting / clarify — just a caption, no metadata
    if tag in ("greeting", "clarify"):
        st.caption("👋 Welcome message")
        return

    # Off-topic — caption + optional escalation notice
    if tag == "off_topic":
        st.caption("↩️ Off-topic — redirected to support topics")
        if msg.get("escalated"):
            sev = msg.get("severity", "HIGH")
            st.error(
                f"{SEVERITY_COLORS.get(sev, '⚠️')} **Escalated — Severity: {sev}**\n\n"
                + "\n".join(f"- {r}" for r in msg.get("reasons", []))
            )
            action = msg.get("recommended_action", "")
            if action:
                st.info(f"**Recommended action:** {action}")
        _render_feedback(msg)
        return

    # Normal RAG response
    conf = msg.get("confidence", 0.0)
    label = confidence_label(conf, threshold)
    badge = {"High": "🟢", "Medium": "🟡", "Low": "🔴"}.get(label, "⚪")
    st.caption(f"{badge} Confidence: **{label}** ({conf:.0%})")

    if msg.get("escalated"):
        sev = msg.get("severity", "")
        sev_icon = SEVERITY_COLORS.get(sev, "⚠️")
        st.error(
            f"{sev_icon} **Escalated — Severity: {sev}**\n\n"
            + "\n".join(f"- {r}" for r in msg.get("reasons", []))
        )
        action = msg.get("recommended_action", "")
        if action:
            st.info(f"**Recommended action:** {action}")

    sources = msg.get("sources", [])
    if sources:
        with st.expander(f"📚 Sources ({len(sources)} chunks)"):
            for i, s in enumerate(sources, 1):
                page_info = f", page {int(s['page']) + 1}" if s.get("page", "") != "" else ""
                st.markdown(
                    f"**{i}. {s['source']}{page_info}** — relevance: {s.get('score', 0):.0%}"
                )

    conf_detail = msg.get("confidence_detail", {})
    if conf_detail and conf_detail.get("breakdown"):
        with st.expander("🔬 Confidence breakdown"):
            col_a, col_b, col_c = st.columns(3)
            col_a.metric("Retrieval quality", f"{conf_detail.get('retrieval', 0):.0%}")
            col_b.metric("Top-chunk score", f"{conf_detail.get('top_score', 0):.0%}")
            col_c.metric("Context density", f"{conf_detail.get('density', 0):.0%}")
            if conf_detail.get("cov_penalty", 0):
                st.warning(f"Coverage penalty applied: −{conf_detail['cov_penalty']:.0%}")
            if conf_detail.get("brev_penalty", 0):
                st.warning(f"Brevity penalty applied: −{conf_detail['brev_penalty']:.0%}")

    m = msg.get("pipeline_metrics", {})
    if m.get("total_ms", 0) > 0:
        with st.expander(f"⏱️ Pipeline timing — {m['total_ms']:.0f} ms total"):
            cols = st.columns(4)
            cols[0].metric("Retrieval", f"{m.get('retrieval_ms', 0):.0f} ms")
            cols[1].metric("LLM", f"{m.get('llm_ms', 0):.0f} ms")
            cols[2].metric("Tokens", m.get("total_tokens", 0))
            cols[3].metric("Chunks", m.get("num_chunks_after_filter", 0))
            if m.get("query_expanded"):
                st.caption("✅ Query expansion was used to improve retrieval recall.")

    _render_feedback(msg)


def _render_feedback(msg: dict) -> None:
    """Render 👍/👎 feedback buttons for a stored message."""
    iid = msg.get("interaction_id")
    if not iid:
        return
    fkey = f"feedback_{iid}"
    if st.session_state.get(fkey) is None:
        col_a, col_b, _ = st.columns([1, 1, 6])
        if col_a.button("👍", key=f"helpful_{iid}", help="Helpful"):
            update_feedback(iid, "helpful")
            st.session_state[fkey] = "helpful"
            st.rerun()
        if col_b.button("👎", key=f"nothelpful_{iid}", help="Not helpful"):
            update_feedback(iid, "not_helpful")
            st.session_state[fkey] = "not_helpful"
            st.rerun()
    else:
        recorded = st.session_state[fkey]
        st.caption("👍 Marked helpful" if recorded == "helpful" else "👎 Marked not helpful")


# ---------------------------------------------------------------------------
# Render conversation history
# ---------------------------------------------------------------------------
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg["role"] == "assistant":
            _render_assistant_meta(msg)

# ---------------------------------------------------------------------------
# Chat input
# ---------------------------------------------------------------------------
if raw_prompt := st.chat_input("Type your support question here…"):

    # ----------------------------------------------------------------
    # Query validation and normalisation
    # ----------------------------------------------------------------
    prompt = raw_prompt.strip()

    if not prompt:
        st.warning("Please type a question to continue.")
        st.stop()

    # Truncate silently — classifier and RAG both benefit from bounded length
    if len(prompt) > config.MAX_QUERY_LENGTH:
        prompt = prompt[: config.MAX_QUERY_LENGTH]

    st.session_state.messages.append({"role": "user", "content": raw_prompt})
    with st.chat_message("user"):
        st.markdown(raw_prompt)

    # ----------------------------------------------------------------
    # Process and respond
    # ----------------------------------------------------------------
    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):

            vs = st.session_state.vector_store
            history = format_for_prompt(st.session_state.history)
            metrics = PipelineMetrics(session_id=st.session_state.session_id)

            # ----------------------------------------------------------
            # Step 1: Classify (fast rule-based first, LLM if needed)
            # ----------------------------------------------------------
            with timed_stage(metrics, "classification"):
                classification = classify_query(prompt)

            query_type      = classification.get("category", "Other")
            is_off_topic    = classification.get("is_off_topic", False)
            is_greeting     = classification.get("is_greeting", False)
            is_too_short    = classification.get("is_too_short", False)

            # ----------------------------------------------------------
            # Step 2A: Too-short / unintelligible query
            # ----------------------------------------------------------
            if is_too_short:
                response_text = get_clarify_response()
                msg_type = "clarify"
                escalation = {
                    "should_escalate": False, "severity": None, "priority": None,
                    "reasons": [], "recommended_action": "", "sla_deadline": None,
                }
                sources = []
                confidence = 0.0
                conf_detail = {}

            # ----------------------------------------------------------
            # Step 2B: Pure greeting — no RAG needed
            # ----------------------------------------------------------
            elif is_greeting:
                response_text = get_greeting_response()
                msg_type = "greeting"
                query_type = "Greeting"
                escalation = {
                    "should_escalate": False, "severity": None, "priority": None,
                    "reasons": [], "recommended_action": "", "sla_deadline": None,
                }
                sources = []
                confidence = 0.0
                conf_detail = {}

            # ----------------------------------------------------------
            # Step 2C: Off-topic — redirect, escalate on repeated streak
            # ----------------------------------------------------------
            elif is_off_topic:
                st.session_state.off_topic_streak += 1
                streak = st.session_state.off_topic_streak
                response_text = get_redirect_message(streak)
                msg_type = "off_topic"
                query_type = "Off-Topic"
                sources = []
                confidence = 0.0
                conf_detail = {}

                if streak >= 2:
                    escalation = {
                        "should_escalate": True,
                        "severity": "HIGH",
                        "priority": 2,
                        "reasons": [
                            f"Customer sent {streak} consecutive off-topic queries — "
                            "may need guidance or be confused about the service"
                        ],
                        "recommended_action": (
                            "Check in with the customer directly. They may be lost "
                            "or looking for a different type of support."
                        ),
                        "sla_deadline": sla_deadline("HIGH"),  # FIX: direct call, no wasted determine_escalation()
                    }
                else:
                    escalation = {
                        "should_escalate": False, "severity": None, "priority": None,
                        "reasons": [], "recommended_action": "", "sla_deadline": None,
                    }

            # ----------------------------------------------------------
            # Step 2D: On-topic — full RAG pipeline
            # ----------------------------------------------------------
            else:
                st.session_state.off_topic_streak = 0  # reset streak
                msg_type = "rag"

                if vs is None:
                    result = generate_response_no_docs(prompt, history, metrics)
                else:
                    result = generate_response(
                        query=prompt,
                        vector_store=vs,
                        conversation_history=history,
                        threshold=threshold,
                        metrics=metrics,
                    )

                response_text = result["response"]
                sources       = result["sources"]
                confidence    = result["confidence"]
                conf_detail   = result.get("confidence_detail", {})
                metrics       = result.get("metrics", metrics)

                escalation = determine_escalation(
                    query=prompt,
                    confidence_score=confidence,
                    is_sensitive_category=classification.get("is_sensitive", False),
                    query_category=query_type,
                    threshold=threshold,
                )

                if result.get("no_docs_found") and vs is not None:
                    escalation["should_escalate"] = True
                    escalation["severity"] = escalation.get("severity") or "MEDIUM"
                    escalation["reasons"].append("No relevant documents found in knowledge base")

                metrics.escalated = escalation["should_escalate"]
                metrics.severity  = escalation.get("severity")
                metrics.priority  = escalation.get("priority")

            # ----------------------------------------------------------
            # Step 3: Render response
            # ----------------------------------------------------------
            st.markdown(response_text)

            if msg_type == "greeting":
                st.caption("👋 Welcome message")

            elif msg_type == "clarify":
                st.caption("❓ Please clarify your question")

            elif msg_type == "off_topic":
                st.caption("↩️ Off-topic — redirected to support topics")
                if escalation["should_escalate"]:
                    st.error(
                        f"🟠 **Escalated — Severity: HIGH**\n\n"
                        + "\n".join(f"- {r}" for r in escalation["reasons"])
                    )
                    st.info(f"**Recommended action:** {escalation['recommended_action']}")

            else:  # rag
                label = confidence_label(confidence, threshold)
                badge = {"High": "🟢", "Medium": "🟡", "Low": "🔴"}.get(label, "⚪")
                st.caption(f"{badge} Confidence: **{label}** ({confidence:.0%})")

                if escalation["should_escalate"]:
                    sev = escalation.get("severity", "")
                    st.error(
                        f"{SEVERITY_COLORS.get(sev, '⚠️')} **Escalated — Severity: {sev}**\n\n"
                        + "\n".join(f"- {r}" for r in escalation["reasons"])
                    )
                    if escalation.get("recommended_action"):
                        st.info(f"**Recommended action:** {escalation['recommended_action']}")

                if sources:
                    with st.expander(f"📚 Sources ({len(sources)} chunks)"):
                        for i, s in enumerate(sources, 1):
                            page_info = (
                                f", page {int(s['page']) + 1}" if s.get("page", "") != "" else ""
                            )
                            st.markdown(
                                f"**{i}. {s['source']}{page_info}** — relevance: {s.get('score', 0):.0%}"
                            )

                if conf_detail and conf_detail.get("breakdown"):
                    with st.expander("🔬 Confidence breakdown"):
                        col_a, col_b, col_c = st.columns(3)
                        col_a.metric("Retrieval quality", f"{conf_detail.get('retrieval', 0):.0%}")
                        col_b.metric("Top-chunk score", f"{conf_detail.get('top_score', 0):.0%}")
                        col_c.metric("Context density", f"{conf_detail.get('density', 0):.0%}")
                        if conf_detail.get("cov_penalty", 0):
                            st.warning(f"Coverage penalty: −{conf_detail['cov_penalty']:.0%}")

                m = metrics.to_dict()
                if m.get("total_ms", 0) > 0:
                    with st.expander(f"⏱️ Pipeline timing — {m['total_ms']:.0f} ms total"):
                        cols = st.columns(4)
                        cols[0].metric("Retrieval", f"{m.get('retrieval_ms', 0):.0f} ms")
                        cols[1].metric("LLM", f"{m.get('llm_ms', 0):.0f} ms")
                        cols[2].metric("Tokens", m.get("total_tokens", 0))
                        cols[3].metric("Chunks", m.get("num_chunks_after_filter", 0))
                        if m.get("query_expanded"):
                            st.caption("✅ Query expansion used.")

        # ----------------------------------------------------------------
        # Step 4: Persist to DB
        # ----------------------------------------------------------------
        # For non-RAG paths, use metric defaults (no retrieval / LLM timing)
        m_dict = metrics.to_dict() if msg_type == "rag" else {}

        iid = log_interaction(
            session_id=st.session_state.session_id,
            query=prompt,
            query_type=query_type,
            response=response_text,
            retrieved_context=(result.get("retrieved_context", "") if msg_type == "rag" else ""),
            sources=sources,
            confidence_score=confidence,
            escalated=escalation["should_escalate"],
            escalation_reasons=escalation["reasons"],
            severity=escalation.get("severity"),
            priority=escalation.get("priority"),
            total_latency_ms=m_dict.get("total_ms"),
            retrieval_latency_ms=m_dict.get("retrieval_ms"),
            llm_latency_ms=m_dict.get("llm_ms"),
            prompt_tokens=m_dict.get("prompt_tokens", 0),
            completion_tokens=m_dict.get("completion_tokens", 0),
            total_tokens=m_dict.get("total_tokens", 0),
            num_chunks=m_dict.get("num_chunks_after_filter", 0),
            avg_retrieval_score=m_dict.get("avg_retrieval_score", 0.0),
            query_expanded=m_dict.get("query_expanded", False),
            confidence_detail=conf_detail,
            request_id=m_dict.get("request_id", ""),
            sla_deadline=escalation.get("sla_deadline"),
            recommended_action=escalation.get("recommended_action", ""),
        )

        # Only add to conversation memory for on-topic exchanges
        if msg_type == "rag":
            st.session_state.history = add_turn(
                st.session_state.history, prompt, response_text
            )
        elif msg_type == "greeting":
            # Add greeting to memory so LLM knows the session opened with it
            st.session_state.history = add_turn(
                st.session_state.history, prompt, response_text
            )
        # off_topic and clarify are NOT added to conversation memory

        # ----------------------------------------------------------------
        # Step 5: Save to message history for UI re-render
        # ----------------------------------------------------------------
        saved_msg = {
            "role": "assistant",
            "content": response_text,
            "msg_type": msg_type,
            "escalated": escalation["should_escalate"],
            "severity": escalation.get("severity"),
            "reasons": escalation["reasons"],
            "recommended_action": escalation.get("recommended_action", ""),
            "interaction_id": iid,
        }

        if msg_type == "rag":
            saved_msg.update({
                "sources": sources,
                "confidence": confidence,
                "confidence_detail": conf_detail,
                "pipeline_metrics": metrics.to_dict(),
            })

        st.session_state.messages.append(saved_msg)

        logger.info(
            "interaction_complete",
            extra={
                "interaction_id": iid,
                "msg_type": msg_type,
                "query_type": query_type,
                "escalated": escalation["should_escalate"],
                "severity": escalation.get("severity"),
                "off_topic_streak": st.session_state.off_topic_streak,
            },
        )

        st.rerun()
