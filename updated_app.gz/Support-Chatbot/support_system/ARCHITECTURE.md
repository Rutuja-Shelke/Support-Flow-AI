# System Architecture

## Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Streamlit Frontend                           │
│                                                                     │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  ┌──────────┐  │
│  │  Chat Page  │  │  Documents   │  │ Escalations│  │   Logs   │  │
│  │  (app.py)   │  │  (Page 1)    │  │  (Page 2)  │  │ (Page 3) │  │
│  └──────┬──────┘  └──────┬───────┘  └──────┬─────┘  └────┬─────┘  │
└─────────┼────────────────┼────────────────┼───────────────┼────────┘
          │                │                │               │
          ▼                ▼                │               │
┌─────────────────────────────────────┐    │               │
│           Business Logic            │    │               │
│                                     │    │               │
│  ┌──────────────────────────────┐   │    │               │
│  │       RAG Pipeline           │   │    │               │
│  │                              │   │    │               │
│  │  User Query                  │   │    │               │
│  │      │                       │   │    │               │
│  │      ▼                       │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  Query Classifier    │    │   │    │               │
│  │  │  (LLM-based)         │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  │             │                │   │    │               │
│  │             ▼                │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  FAISS Vector Search │    │   │    │               │
│  │  │  (top-k retrieval)   │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  │             │                │   │    │               │
│  │             ▼                │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  Context + Prompt    │    │   │    │               │
│  │  │  Builder             │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  │             │                │   │    │               │
│  │             ▼                │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  OpenAI gpt-4o-mini  │    │   │    │               │
│  │  │  (grounded response) │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  │             │                │   │    │               │
│  │             ▼                │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  Confidence Scorer   │    │   │    │               │
│  │  │  (retrieval quality) │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  │             │                │   │    │               │
│  │             ▼                │   │    │               │
│  │  ┌──────────────────────┐    │   │    │               │
│  │  │  Escalation Decision │    │   │    │               │
│  │  │  Engine              │    │   │    │               │
│  │  └──────────┬───────────┘    │   │    │               │
│  └─────────────┼────────────────┘   │    │               │
│                │                    │    │               │
└────────────────┼────────────────────┼────┼───────────────┘
                 │                    │    │
                 ▼                    ▼    ▼
┌──────────────────────────────────────────────────────────┐
│                    Persistence Layer                     │
│                                                          │
│  ┌───────────────────────┐   ┌────────────────────────┐ │
│  │   FAISS Vector Store  │   │   SQLite Database      │ │
│  │   (disk-persisted)    │   │                        │ │
│  │                       │   │  ┌──────────────────┐  │ │
│  │  - Document chunks    │   │  │  interactions    │  │ │
│  │  - Embeddings         │   │  │  - query         │  │ │
│  │  - Source metadata    │   │  │  - response      │  │ │
│  │                       │   │  │  - confidence    │  │ │
│  └───────────────────────┘   │  │  - escalated     │  │ │
│                              │  │  - feedback      │  │ │
│                              │  └──────────────────┘  │ │
│                              │  ┌──────────────────┐  │ │
│                              │  │  escalations     │  │ │
│                              │  │  - ticket id     │  │ │
│                              │  │  - reasons       │  │ │
│                              │  │  - status        │  │ │
│                              │  │  - agent notes   │  │ │
│                              │  └──────────────────┘  │ │
│                              └────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

---

## Component Descriptions

### Frontend (Streamlit)

| Page | Purpose |
|---|---|
| `app.py` (Chat) | Main customer-facing chat interface with real-time RAG responses |
| `pages/1_Documents.py` | Upload PDFs/TXT files, monitor index status, clear knowledge base |
| `pages/2_Escalations.py` | Human-agent queue to review and action escalated tickets |
| `pages/3_Logs.py` | Full audit trail with filters and CSV export |

### RAG Pipeline (`src/rag_engine.py`)

The retrieval-augmented generation pipeline runs sequentially:

1. **Embed** the query using `text-embedding-3-small`
2. **Search** FAISS for the top-5 most similar document chunks
3. **Format** a context block with source labels
4. **Prompt** `gpt-4o-mini` with system rules + conversation history + context
5. **Return** the response, sources, and raw retrieval scores

### Confidence Scoring (`src/confidence_scorer.py`)

Confidence is computed as a **rank-weighted average** of FAISS relevance scores:

```
confidence = Σ(score_i × 1/(i+1)) / Σ(1/(i+1))
```

A **coverage penalty** (−0.30) is applied when the LLM indicates it could not answer from the context. Final score is clamped to [0, 1].

### Escalation Engine (`src/escalation_handler.py`)

A query is escalated if **any one** of these conditions is true:

| Trigger | Details |
|---|---|
| Low confidence | `confidence_score < threshold` (default 0.60) |
| Sensitive category | Query classified as Legal, Complaint, or Security |
| Sensitive keyword | Match against hard-coded keyword list |
| Human request | User says "speak to a human", "real agent", etc. |

### Document Processing (`src/document_processor.py`)

- **PDF**: `PyPDFLoader` extracts text per page; page numbers preserved in metadata
- **TXT/MD**: Raw decode; treated as a single document
- **Splitter**: `RecursiveCharacterTextSplitter` with 800-char chunks and 100-char overlap
- **Storage**: All chunks embedded and stored in a disk-persisted FAISS index

### Memory Manager (`src/memory_manager.py`)

A sliding window of the last 10 turns (20 messages) is prepended to every LLM call. This allows the assistant to refer back to earlier context without unbounded token growth.

---

## Data Flow Diagram

```
User types query
       │
       ▼
  Classify query ──────────────────────────┐
  (gpt-4o-mini, JSON output)               │
       │                                   │
       ▼                                   │
  Embed query                              │
  (text-embedding-3-small)                 │
       │                                   │
       ▼                                   │
  FAISS similarity search                  │
  → top-5 chunks + scores                  │
       │                                   │
       ▼                                   │
  Build prompt                             │
  [system] + [history] + [context+query]   │
       │                                   │
       ▼                                   │
  gpt-4o-mini completion                   │
  (temperature=0.2, max_tokens=1024)       │
       │                                   │
       ▼                                   │
  Score confidence ◄────── retrieval scores│
  + coverage penalty                       │
       │                                   │
       ▼                                   │
  Escalation decision ◄────────────────────┘
  (confidence + sensitivity + keywords)
       │
       ├──► Display response + citations
       ├──► Show confidence badge
       ├──► Show escalation notice (if triggered)
       ├──► Log to SQLite
       └──► Offer 👍/👎 feedback buttons
```
