# AI-Powered Customer Support Workflow System

An enterprise-grade, RAG-based AI customer support system that answers L1 queries from company documents, escalates uncertain or sensitive queries to human agents, and maintains a full audit trail.

---

## Features

| Feature | Details |
|---|---|
| **RAG pipeline** | LangChain + FAISS vector search, `text-embedding-3-small` embeddings |
| **LLM** | OpenAI `gpt-4o-mini` — grounded, low-temperature responses |
| **Confidence scoring** | Rank-weighted retrieval score + LLM coverage check |
| **Escalation engine** | Low confidence · Sensitive keywords · Query category · Explicit human request |
| **Conversation memory** | Sliding 10-turn window passed to every LLM call |
| **Source citations** | Every response links back to the exact document chunk |
| **Feedback loop** | 👍/👎 buttons on every response, stored in SQLite |
| **Document ingestion** | PDF and TXT/MD, chunked with overlap |
| **Audit log** | Full SQLite log of every interaction |
| **Escalation queue** | Agent UI to review, action, and close escalations |
| **CSV export** | Both logs and escalations exportable |

---

## Quick Start

### 1. Clone / open the project

```bash
git clone <repo-url>
cd support_system
```

### 2. Create a virtual environment (optional but recommended)

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set your OpenAI API key

```bash
export OPENAI_API_KEY="sk-..."
```

Or create a `.env` file:

```
OPENAI_API_KEY=sk-...
```

### 5. Run the app

```bash
streamlit run app.py --server.port 5000
```

Open [http://localhost:5000](http://localhost:5000) in your browser.

---

## Usage

1. **Upload documents** — Go to the **Documents** page and upload your company PDFs or text files. The system will chunk and embed them automatically.
2. **Chat** — Return to the **Chat** page and ask support questions. Responses cite their sources and show a confidence score.
3. **Escalations** — Queries below the confidence threshold (or flagged for sensitivity) are routed to the **Escalation Queue**. Agents can update status and add notes.
4. **Logs** — The **Interaction Logs** page shows every query, response, confidence score, and feedback, with CSV export.

---

## Configuration

All tunable settings are in `src/config.py`:

| Setting | Default | Description |
|---|---|---|
| `CHAT_MODEL` | `gpt-4o-mini` | LLM for generating responses |
| `EMBEDDING_MODEL` | `text-embedding-3-small` | Model for document embeddings |
| `TOP_K_CHUNKS` | `5` | Chunks retrieved per query |
| `CHUNK_SIZE` | `800` | Characters per chunk |
| `CHUNK_OVERLAP` | `100` | Overlap between consecutive chunks |
| `DEFAULT_CONFIDENCE_THRESHOLD` | `0.60` | Escalation trigger (also adjustable in the sidebar) |
| `SENSITIVE_KEYWORDS` | See config | Keywords that force escalation |
| `SENSITIVE_CATEGORIES` | Legal, Complaint, Security | Query types that force escalation |

---

## Project Structure

```
support_system/
├── app.py                     # Main Streamlit app — Chat interface
├── requirements.txt
├── README.md
├── ARCHITECTURE.md
├── WORKFLOW.md
├── DEMO_SCRIPT.md
├── .streamlit/
│   └── config.toml            # Server config (port 5000)
├── pages/
│   ├── 1_Documents.py         # Document upload & management
│   ├── 2_Escalations.py       # Human-agent escalation queue
│   └── 3_Logs.py              # Full interaction audit log
├── src/
│   ├── config.py              # All tunable settings
│   ├── document_processor.py  # PDF/TXT ingestion and chunking
│   ├── vector_store.py        # FAISS create / load / search
│   ├── rag_engine.py          # Retrieval + LLM generation
│   ├── classifier.py          # Query type classification
│   ├── confidence_scorer.py   # Confidence scoring logic
│   ├── escalation_handler.py  # Escalation decision logic
│   ├── memory_manager.py      # Sliding-window conversation memory
│   └── interaction_logger.py  # SQLite audit logger
└── data/
    ├── vector_store/          # Persisted FAISS index
    └── interactions.db        # SQLite database
```

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `OPENAI_API_KEY` | ✅ Yes | Your OpenAI API key |

---

## Supported Document Formats

| Format | Notes |
|---|---|
| `.pdf` | Text-based PDFs. Scanned/image PDFs require OCR preprocessing. |
| `.txt` | Plain text files |
| `.md` | Markdown files |
