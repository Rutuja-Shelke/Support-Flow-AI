"""
Escalations page — priority-sorted, SLA-tracked human-agent queue.
"""
import os
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.ui_styles import inject_css
from src.interaction_logger import init_db, get_all_escalations, update_escalation_status, get_stats
from src.escalation_handler import SEVERITY_COLORS, sla_remaining

init_db()
st.set_page_config(page_title="Escalations — AI Support", page_icon="🚨", layout="wide")
inject_css()

st.markdown("<h1 style='margin-bottom:2px'>🚨 Escalation Queue</h1>", unsafe_allow_html=True)
st.caption(
    "Queries escalated by the AI, ordered by severity. "
    "CRITICAL tickets must be actioned within 1 hour."
)

# ---------------------------------------------------------------------------
# Stats row
# ---------------------------------------------------------------------------
stats = get_stats()

def _sev_card(label: str, value: int, bg: str, border: str, text: str) -> str:
    return (
        f"<div style='background:{bg};border:1px solid {border};border-radius:10px;"
        f"padding:12px 16px;text-align:center'>"
        f"<div style='font-size:22px;font-weight:700;color:{text}'>{value}</div>"
        f"<div style='font-size:11px;font-weight:600;color:{text};opacity:0.8;margin-top:2px'>{label}</div>"
        "</div>"
    )

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total Escalations", stats["escalated"])
c2.metric("Open Tickets",      stats["open_escalations"])

with c3:
    st.markdown(_sev_card("🔴 CRITICAL", stats.get("sev_critical", 0),
                           "#fef2f2", "#fecaca", "#dc2626"), unsafe_allow_html=True)
with c4:
    st.markdown(_sev_card("🟠 HIGH", stats.get("sev_high", 0),
                           "#fff7ed", "#fed7aa", "#c2410c"), unsafe_allow_html=True)
with c5:
    st.markdown(_sev_card("🟡 MED + 🔵 LOW",
                           stats.get("sev_medium", 0) + stats.get("sev_low", 0),
                           "#fffbeb", "#fde68a", "#b45309"), unsafe_allow_html=True)

st.divider()

# ---------------------------------------------------------------------------
# Load + filter
# ---------------------------------------------------------------------------
escalations = get_all_escalations(limit=500)

if not escalations:
    st.success("🎉 No escalations yet — the AI is handling all queries!", icon="✅")
    st.stop()

col_f1, col_f2 = st.columns(2)
status_filter = col_f1.selectbox(
    "Filter by status", ["All open", "open", "in_progress", "resolved", "All"]
)
sev_filter = col_f2.selectbox(
    "Filter by severity", ["All", "CRITICAL", "HIGH", "MEDIUM", "LOW", "Unclassified"]
)

filtered = escalations
if status_filter == "All open":
    filtered = [e for e in filtered if e["status"] != "resolved"]
elif status_filter != "All":
    filtered = [e for e in filtered if e["status"] == status_filter]
if sev_filter != "All":
    if sev_filter == "Unclassified":
        filtered = [e for e in filtered if not e.get("severity")]
    else:
        filtered = [e for e in filtered if e.get("severity") == sev_filter]

if not filtered:
    st.info("No escalations match the selected filters.")
    st.stop()

st.markdown(
    f"<p style='color:#6b7280;font-size:14px'>Showing <strong>{len(filtered)}</strong> ticket(s)</p>",
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Severity badge
# ---------------------------------------------------------------------------
SEV_STYLES: dict[str, tuple[str, str, str]] = {
    "CRITICAL": ("#fef2f2", "#dc2626", "🔴"),
    "HIGH":     ("#fff7ed", "#c2410c", "🟠"),
    "MEDIUM":   ("#fffbeb", "#b45309", "🟡"),
    "LOW":      ("#eff6ff", "#1d4ed8", "🔵"),
}
STATUS_LABELS = {
    "open":        ("🔴 Open",        "error"),
    "in_progress": ("🟡 In Progress",  "warning"),
    "resolved":    ("🟢 Resolved",     "success"),
}


def _sev_badge(sev: str | None) -> str:
    if not sev:
        return "⚪ Unknown"
    icon = SEV_STYLES.get(sev, ("", "", "⚠️"))[2]
    return f"{icon} {sev}"


# ---------------------------------------------------------------------------
# Render tickets
# ---------------------------------------------------------------------------
for esc in filtered:
    sev    = esc.get("severity") or "—"
    status = esc.get("status", "open")
    status_label, _ = STATUS_LABELS.get(status, ("⚪ " + status, "info"))
    sla    = ""
    if esc.get("sla_deadline") and status != "resolved":
        sla = f" · SLA: {sla_remaining(esc['sla_deadline'])}"

    auto_expand = sev == "CRITICAL" or (
        esc.get("sla_deadline")
        and "Overdue" in sla_remaining(esc.get("sla_deadline", ""))
        and status != "resolved"
    )

    header = (
        f"{_sev_badge(esc.get('severity'))} · "
        f"Ticket #{esc['id']} · {status_label}{sla} · {esc['timestamp'][:16]}"
    )

    with st.expander(header, expanded=auto_expand):

        st.markdown(
            f"<div style='background:#f8fafc;border-left:3px solid #94a3b8;"
            f"border-radius:0 6px 6px 0;padding:10px 14px;margin-bottom:12px;"
            f"font-style:italic;color:#374151'>{esc['query']}</div>",
            unsafe_allow_html=True,
        )

        if esc.get("reasons"):
            st.markdown("**Escalation Reasons:**")
            for reason in esc["reasons"].split(";"):
                if reason.strip():
                    st.markdown(f"- {reason.strip()}")

        if esc.get("recommended_action"):
            st.info(f"💡 **Recommended Action:** {esc['recommended_action']}", icon="💡")

        if esc.get("sla_deadline") and status != "resolved":
            remaining = sla_remaining(esc["sla_deadline"])
            sla_hours = {"CRITICAL": 1, "HIGH": 4, "MEDIUM": 24, "LOW": 48}.get(sev, "—")
            overdue   = "Overdue" in remaining
            badge_color = "#dc2626" if overdue else "#2563eb"
            st.markdown(
                f"<span style='background:{'#fee2e2' if overdue else '#eff6ff'};"
                f"color:{badge_color};border-radius:6px;padding:3px 10px;"
                f"font-size:12px;font-weight:600'>"
                f"SLA: {sla_hours}h · {remaining}</span>",
                unsafe_allow_html=True,
            )

        if esc.get("agent_notes"):
            st.success(f"**Agent Notes:** {esc['agent_notes']}", icon="📝")

        st.divider()

        col_status, col_notes = st.columns([1, 2])
        current_idx = (
            ["open", "in_progress", "resolved"].index(status)
            if status in ["open", "in_progress", "resolved"] else 0
        )
        new_status = col_status.selectbox(
            "Update Status", options=["open", "in_progress", "resolved"],
            index=current_idx, key=f"status_{esc['id']}",
        )
        new_notes = col_notes.text_input(
            "Agent Notes", value=esc.get("agent_notes") or "",
            key=f"notes_{esc['id']}",
            placeholder="Resolution notes, case ID, next steps…",
        )

        btn_type = "primary" if status != "resolved" else "secondary"
        if st.button("💾 Save changes", key=f"save_{esc['id']}", type=btn_type):
            update_escalation_status(esc["id"], new_status, new_notes)
            st.success(f"Ticket #{esc['id']} updated → **{new_status}**")
            st.rerun()

# ---------------------------------------------------------------------------
# Summary table
# ---------------------------------------------------------------------------
st.divider()
st.markdown("### Summary Table")

df_data = []
for e in filtered:
    sla_str = (
        sla_remaining(e["sla_deadline"])
        if e.get("sla_deadline") and e.get("status") != "resolved"
        else "—"
    )
    df_data.append({
        "ID":        e["id"],
        "Severity":  _sev_badge(e.get("severity")),
        "Status":    e.get("status", "—"),
        "SLA":       sla_str,
        "Query":     (e["query"] or "")[:60] + ("…" if len(e.get("query", "")) > 60 else ""),
        "Timestamp": (e["timestamp"] or "")[:16],
    })

if df_data:
    st.dataframe(pd.DataFrame(df_data), use_container_width=True, hide_index=True)

st.divider()
if st.button("📥 Export escalations as CSV"):
    df = pd.DataFrame(escalations)
    st.download_button(
        "⬇️ Download CSV",
        data=df.to_csv(index=False),
        file_name="escalations.csv",
        mime="text/csv",
    )
