"""
Documents page — Upload and manage the knowledge base.
"""
import os
import shutil
import sys

import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.ui_styles import inject_css
from src.document_processor import process_uploaded_file
from src.vector_store import (
    create_vector_store, add_documents, save_vector_store,
    load_vector_store, VECTOR_STORE_PATH,
)
from src.interaction_logger import init_db

init_db()
st.set_page_config(page_title="Documents — AI Support", page_icon="📚", layout="wide")
inject_css()

st.markdown("<h1 style='margin-bottom:2px'>📚 Knowledge Base</h1>", unsafe_allow_html=True)
st.caption(
    "Upload your company documents here. The system will index them using local embeddings "
    "(all-MiniLM-L6-v2) and use them to answer customer queries with source citations."
)

if "vector_store" not in st.session_state:
    st.session_state.vector_store = load_vector_store()
if "doc_names" not in st.session_state:
    st.session_state.doc_names = []

# ---------------------------------------------------------------------------
# Upload section
# ---------------------------------------------------------------------------
st.markdown("### Upload Documents")

col_info, _ = st.columns([3, 1])
with col_info:
    st.info(
        "**Supported formats:** PDF · TXT · MD\n\n"
        "You can upload multiple files at once. Each file is chunked and embedded "
        "into the FAISS vector index using local sentence-transformers (no API cost).",
        icon="📎",
    )

uploaded_files = st.file_uploader(
    "Choose files",
    type=["pdf", "txt", "md"],
    accept_multiple_files=True,
    label_visibility="collapsed",
)

if uploaded_files:
    if st.button("➕ Index selected files", type="primary", use_container_width=True):
        all_chunks, results = [], []

        progress = st.progress(0, text="Processing files…")
        for i, uploaded_file in enumerate(uploaded_files):
            file_bytes = uploaded_file.read()
            chunks, msg = process_uploaded_file(file_bytes, uploaded_file.name)
            results.append((uploaded_file.name, msg, len(chunks)))
            all_chunks.extend(chunks)
            if uploaded_file.name not in st.session_state.doc_names:
                st.session_state.doc_names.append(uploaded_file.name)
            progress.progress((i + 1) / len(uploaded_files), text=f"Processing {uploaded_file.name}…")

        progress.empty()

        if all_chunks:
            with st.spinner("Building embeddings (runs locally — first time may take ~10s)…"):
                if st.session_state.vector_store is None:
                    st.session_state.vector_store = create_vector_store(all_chunks)
                else:
                    st.session_state.vector_store = add_documents(
                        st.session_state.vector_store, all_chunks
                    )
                save_vector_store(st.session_state.vector_store)

            st.success(
                f"✅ Indexed **{len(all_chunks)} chunks** from {len(uploaded_files)} file(s). "
                "The chat page is ready.",
                icon="✅",
            )
        else:
            st.warning("No valid content was extracted from the uploaded files.")

        st.markdown("#### Processing Results")
        for name, msg, count in results:
            if count > 0:
                st.success(f"**{name}** — {count} chunks", icon="✓")
            else:
                st.error(f"**{name}** — {msg}", icon="✗")

# ---------------------------------------------------------------------------
# Current knowledge base status
# ---------------------------------------------------------------------------
st.divider()
st.markdown("### Current Knowledge Base")

if st.session_state.vector_store is not None:
    col1, col2 = st.columns([3, 1])
    with col1:
        if st.session_state.doc_names:
            st.markdown(
                f"<div style='background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;"
                f"padding:14px 18px'>"
                f"<strong style='color:#15803d'>{len(st.session_state.doc_names)} document(s) indexed</strong><br>"
                + "".join(f"<div style='margin-top:6px;color:#166534'>📄 {n}</div>"
                          for n in st.session_state.doc_names)
                + "</div>",
                unsafe_allow_html=True,
            )
        else:
            st.info("Documents are indexed but session names were cleared. Reload to see them.")
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🗑️ Clear knowledge base", type="secondary", use_container_width=True):
            if os.path.exists(VECTOR_STORE_PATH):
                shutil.rmtree(VECTOR_STORE_PATH)
            st.session_state.vector_store = None
            st.session_state.doc_names = []
            st.success("Knowledge base cleared.")
            st.rerun()
else:
    st.markdown(
        "<div style='background:#fffbeb;border:1px solid #fde68a;border-radius:10px;"
        "padding:16px 18px;color:#92400e'>"
        "⚠️ <strong>No documents indexed yet.</strong> Upload files above to build the knowledge base."
        "</div>",
        unsafe_allow_html=True,
    )

# ---------------------------------------------------------------------------
# Tips
# ---------------------------------------------------------------------------
st.divider()
with st.expander("💡 Tips for best indexing results"):
    st.markdown("""
    - **Chunk quality matters** — clean, well-structured documents produce better retrieval
    - **Use text-based PDFs** — scanned PDFs without OCR may produce garbled text
    - **Cover your FAQ topics** — include policy docs, product guides, and troubleshooting manuals
    - **Re-upload if you update a document** — the system appends new chunks; old ones remain
    - **Embeddings are local** — using `sentence-transformers/all-MiniLM-L6-v2`, no API cost
    - **Confidence threshold** — tune it in the sidebar on the Chat page (higher = stricter escalation)
    """)
