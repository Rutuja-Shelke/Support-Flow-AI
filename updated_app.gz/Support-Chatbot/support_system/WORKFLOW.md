# Workflow Explanation

## End-to-End Customer Support Workflow

This document describes the full lifecycle of a customer interaction through the AI Support System.

---

## Phase 1 — Knowledge Base Setup (One-time / Admin)

```
Admin uploads documents
        │
        ▼
Document Processor
  ├── PyPDFLoader (PDF) or TextLoader (TXT/MD)
  ├── RecursiveCharacterTextSplitter → chunks (800 chars, 100 overlap)
  └── Source metadata attached (filename + page number)
        │
        ▼
OpenAI Embeddings (text-embedding-3-small)
  └── Each chunk → 1536-dimension vector
        │
        ▼
FAISS Index
  ├── Vectors stored in L2-indexed flat index
  ├── Saved to disk (data/vector_store/)
  └── Loaded into session state on startup
```

**Outcome:** A searchable, persistent vector index ready to serve queries.

---

## Phase 2 — Query Processing (Per Customer Message)

### Step 1 — Query Classification

The raw user query is sent to `gpt-4o-mini` with a structured JSON prompt to classify it into one of:

```
General | Technical | Billing | Account | Complaint | Legal | Security | Other
```

The classifier also returns an `is_sensitive` boolean and a one-sentence reasoning string.

**Why this matters:** Sensitive categories (Legal, Complaint, Security) trigger automatic escalation even if retrieval confidence is high.

---

### Step 2 — Retrieval (RAG)

The query is embedded using `text-embedding-3-small` and compared against all indexed document chunks via FAISS cosine similarity.

The **top-5 most relevant chunks** are retrieved, each with:
- Document text
- Source filename and page number
- Relevance score in [0, 1]

```
Query embedding ──► FAISS index ──► top-5 (chunk, score) pairs
```

---

### Step 3 — Context + Prompt Construction

The retrieved chunks are formatted into a structured context block:

```
[Source 1: returns-policy.pdf, page 3]
Our standard return window is 30 days from the date of purchase...

---

[Source 2: faq.txt]
Items must be in their original packaging to qualify for a full refund...
```

This is prepended to the user's question and injected into the LLM prompt alongside:
- A strict **system prompt** instructing the model to answer ONLY from context
- The last 10 turns of **conversation history**

---

### Step 4 — LLM Response Generation

`gpt-4o-mini` generates the response at `temperature=0.2` (low, for factual consistency).

The system prompt enforces:
1. Answer only from provided context
2. If context is insufficient, say so explicitly (do NOT hallucinate)
3. Cite sources naturally
4. Acknowledge customer emotions before answering complaints

---

### Step 5 — Confidence Scoring

A confidence score is computed from two signals:

**Signal A — Retrieval quality (rank-weighted average):**
```
confidence = (s1×1.0 + s2×0.5 + s3×0.33 + ...) / (1.0 + 0.5 + 0.33 + ...)
```
where s1, s2, … are the FAISS relevance scores of the top-5 chunks.

**Signal B — Coverage penalty:**
If the LLM response contains phrases like "I don't have enough information" or "not in my knowledge base", a −0.30 penalty is applied.

**Thresholds:**
- 🟢 High: ≥ 0.80
- 🟡 Medium: ≥ threshold (default 0.60)
- 🔴 Low: < threshold → triggers escalation

---

### Step 6 — Escalation Decision

The escalation engine checks four independent signals:

| Signal | Check |
|---|---|
| Confidence | `score < threshold` |
| Category | Classification is Legal / Complaint / Security |
| Keywords | Query contains words like "lawsuit", "fraud", "refund" |
| Human request | User says "speak to human", "real agent", etc. |

If **any signal fires**, the response is flagged as escalated.

The customer sees a clear escalation notice. The ticket is created in the `escalations` table for a human agent to review.

---

### Step 7 — Response Delivery

The Streamlit UI renders:

1. **Response text** — the grounded LLM answer
2. **Confidence badge** — 🟢/🟡/🔴 with percentage
3. **Escalation notice** — if triggered, lists all reasons
4. **Source citations** — expandable panel listing source documents and relevance scores
5. **Feedback buttons** — 👍 / 👎 recorded against the interaction ID

---

### Step 8 — Logging

Every interaction is stored in SQLite with:
- Session ID, timestamp
- Raw query + response
- Full retrieved context (for audit)
- Confidence score
- Escalation status and reasons
- Customer feedback (once submitted)

---

## Phase 3 — Human Agent Handling

When a ticket is escalated:

1. It appears in the **Escalation Queue** (Page 2) with status `open`
2. A human agent reviews the query, reasons, and optionally the full context from the Logs page
3. The agent updates status to `in_progress` and adds resolution notes
4. After resolving, status is set to `resolved`

---

## Confidence Threshold Tuning

The threshold is adjustable in the sidebar (0.30–0.90) without restarting the app.

**Trade-offs:**
- **Lower threshold (e.g. 0.40)** → fewer escalations, AI handles more, higher hallucination risk
- **Higher threshold (e.g. 0.80)** → more escalations, lower risk, higher human cost
- **Default 0.60** — balanced starting point for most enterprise use cases

For high-stakes domains (legal, medical, financial), set to 0.75+.

---

## Hallucination Prevention Strategy

This system employs multiple layers to prevent fabricated responses:

1. **Retrieval grounding** — the LLM sees only retrieved document text, not its training data
2. **System prompt rules** — explicit instruction to say "I don't know" rather than guess
3. **Low temperature** — 0.2 reduces creative/speculative outputs
4. **Coverage penalty** — uncertainty phrases reduce the confidence score
5. **Source citations** — every claim is traceable to a specific document chunk
6. **Escalation safety net** — uncertain responses go to a human rather than being served
