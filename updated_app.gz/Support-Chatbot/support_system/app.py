"""
AI-Powered Customer Support Workflow System — Main Chat Page
Provider: Google Gemini 1.5 Flash + sentence-transformers/all-MiniLM-L6-v2
"""
import os
import sys
import uuid

import streamlit as st

sys.path.insert(0, os.path.dirname(__file__))

from src import config
from src.ui_styles import inject_css
from src.interaction_logger import init_db, log_interaction, update_feedback, get_stats
from src.vector_store import load_vector_store
from src.rag_engine import generate_response, generate_response_no_docs
from src.classifier import (
    classify_query, get_redirect_message,
    get_greeting_response, get_clarify_response,
)
from src.escalation_handler import determine_escalation, sla_deadline, SEVERITY_COLORS
from src.memory_manager import init_history, add_turn, format_for_prompt, clear_history
from src.confidence_scorer import confidence_label
from src.observability import PipelineMetrics, get_logger, timed_stage

logger = get_logger("app")

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI Support System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)
inject_css()
init_db()

# ---------------------------------------------------------------------------
# API key guard
# ---------------------------------------------------------------------------
if not config.GEMINI_API_KEY:
    st.error(
        "**GEMINI_API_KEY is not set.**\n\n"
        "Add your Gemini API key as a Replit Secret named `GEMINI_API_KEY` "
        "and restart the app. You can get a free API key at "
        "[aistudio.google.com](https://aistudio.google.com/app/apikey).",
        icon="🔑",
    )
    st.stop()

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "session_id"       not in st.session_state: st.session_state.session_id       = str(uuid.uuid4())
if "messages"         not in st.session_state: st.session_state.messages         = []
if "history"          not in st.session_state: st.session_state.history          = init_history()
if "vector_store"     not in st.session_state: st.session_state.vector_store     = load_vector_store()
if "doc_names"        not in st.session_state: st.session_state.doc_names        = []
if "off_topic_streak" not in st.session_state: st.session_state.off_topic_streak = 0

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown(
        "<div style='padding:4px 0 2px'>"
        "<span style='font-size:22px;font-weight:700;color:#f1f5f9;letter-spacing:-0.02em'>"
        "🤖 AI Support</span><br>"
        "<span style='font-size:11px;color:#64748b;font-weight:500;letter-spacing:0.04em;text-transform:uppercase'>"
        "Enterprise Workflow System</span></div>",
        unsafe_allow_html=True,
    )
    st.divider()

    threshold = st.slider(
        "Confidence Threshold",
        min_value=0.30, max_value=0.90,
        value=config.DEFAULT_CONFIDENCE_THRESHOLD,
        step=0.05, format="%.2f",
        help="Responses below this score are escalated. Higher = stricter.",
    )

    st.divider()

    # Knowledge base status
    if st.session_state.vector_store is not None:
        st.markdown(
            "<div style='background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);"
            "border-radius:8px;padding:10px 12px;margin-bottom:8px'>"
            "<span style='color:#86efac;font-size:12px;font-weight:600'>● KNOWLEDGE BASE READY</span>",
            unsafe_allow_html=True,
        )
        if st.session_state.doc_names:
            for name in st.session_state.doc_names:
                st.caption(f"📄 {name}")
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.markdown(
            "<div style='background:rgba(234,179,8,0.12);border:1px solid rgba(234,179,8,0.3);"
            "border-radius:8px;padding:10px 12px;margin-bottom:8px'>"
            "<span style='color:#fde047;font-size:12px;font-weight:600'>⚠ NO DOCUMENTS LOADED</span><br>"
            "<span style='color:#94a3b8;font-size:11px'>Upload on the Documents page</span>"
            "</div>",
            unsafe_allow_html=True,
        )

    st.divider()

    # Session stats
    st.markdown(
        "<span style='font-size:11px;font-weight:600;color:#64748b;"
        "letter-spacing:0.06em;text-transform:uppercase'>Session Stats</span>",
        unsafe_allow_html=True,
    )
    stats = get_stats()
    c1, c2 = st.columns(2)
    c1.metric("Queries", stats["total"])
    c2.metric("Open Esc.", stats["open_escalations"], delta_color="inverse")
    c1.metric("👍 Helpful", stats["helpful"])
    c2.metric("👎 Not helpful", stats["not_helpful"])

    if stats.get("avg_latency_ms", 0) > 0:
        st.caption(f"Avg latency: **{stats['avg_latency_ms']:.0f} ms**")
    if stats.get("avg_confidence", 0) > 0:
        st.caption(f"Avg confidence: **{stats['avg_confidence']:.0%}**")

    sev_open = [
        ("🔴 CRITICAL", stats.get("sev_critical", 0)),
        ("🟠 HIGH", stats.get("sev_high", 0)),
        ("🟡 MEDIUM", stats.get("sev_medium", 0)),
        ("🔵 LOW", stats.get("sev_low", 0)),
    ]
    if any(v > 0 for _, v in sev_open):
        st.caption("**Open by severity:**")
        for lbl, count in sev_open:
            if count:
                st.caption(f"  {lbl}: {count}")

    st.divider()

    col_a, col_b = st.columns(2)
    if col_a.button("🗑️ Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.history = clear_history()
        st.session_state.off_topic_streak = 0
        st.rerun()
    if col_b.button("🔄 Reload KB", use_container_width=True):
        st.session_state.vector_store = load_vector_store()
        st.rerun()

    st.divider()
    st.caption("Powered by **Gemini 1.5 Flash** · Embeddings: **all-MiniLM-L6-v2**")

# ---------------------------------------------------------------------------
# Page header
# ---------------------------------------------------------------------------
st.markdown(
    "<h1 style='margin-bottom:2px'>Customer Support Chat</h1>"
    "<p style='color:#6b7280;font-size:14px;margin-top:0'>"
    "Responses are grounded in company documents. "
    "Uncertain or sensitive queries are automatically escalated.</p>",
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Helpers for rendering stored assistant messages
# ---------------------------------------------------------------------------

def _confidence_badge_html(label: str, score: float) -> str:
    colors = {
        "High":   ("#dcfce7", "#16a34a", "🟢"),
        "Medium": ("#fef9c3", "#a16207", "🟡"),
        "Low":    ("#fee2e2", "#dc2626", "🔴"),
    }
    bg, fg, icon = colors.get(label, ("#f1f5f9", "#475569", "⚪"))
    return (
        f"<span style='background:{bg};color:{fg};border-radius:20px;"
        f"padding:3px 10px;font-size:12px;font-weight:600'>"
        f"{icon} {label} confidence · {score:.0%}</span>"
    )


def _render_assistant_meta(msg: dict) -> None:
    tag = msg.get("msg_type", "rag")

    if tag in ("greeting", "clarify"):
        st.caption("👋 Welcome message" if tag == "greeting" else "❓ Clarification requested")
        return

    if tag == "off_topic":
        st.caption("↩️ Off-topic query — redirected")
        if msg.get("escalated"):
            sev = msg.get("severity", "HIGH")
            st.error(
                f"{SEVERITY_COLORS.get(sev, '⚠️')} **Escalated — Severity: {sev}**\n\n"
                + "\n".join(f"- {r}" for r in msg.get("reasons", []))
            )
            if msg.get("recommended_action"):
                st.info(f"**Recommended action:** {msg['recommended_action']}")
        _render_feedback(msg)
        return

    # RAG response
    conf  = msg.get("confidence", 0.0)
    label = confidence_label(conf, threshold)
    st.markdown(_confidence_badge_html(label, conf), unsafe_allow_html=True)

    if msg.get("escalated"):
        sev = msg.get("severity", "")
        st.error(
            f"{SEVERITY_COLORS.get(sev, '⚠️')} **Escalated — Severity: {sev}**\n\n"
            + "\n".join(f"- {r}" for r in msg.get("reasons", []))
        )
        if msg.get("recommended_action"):
            st.info(f"**Recommended action:** {msg['recommended_action']}")

    sources = msg.get("sources", [])
    if sources:
        with st.expander(f"📚 Sources ({len(sources)} chunks)"):
            for i, s in enumerate(sources, 1):
                page_info = f", page {int(s['page']) + 1}" if s.get("page", "") != "" else ""
                score_pct = f"{s.get('score', 0):.0%}"
                st.markdown(
                    f"**{i}.** `{s['source']}{page_info}` — relevance: **{score_pct}**"
                )

    conf_detail = msg.get("confidence_detail", {})
    if conf_detail and conf_detail.get("breakdown"):
        with st.expander("🔬 Confidence breakdown"):
            col_a, col_b, col_c = st.columns(3)
            col_a.metric("Retrieval quality", f"{conf_detail.get('retrieval', 0):.0%}")
            col_b.metric("Top-chunk score",   f"{conf_detail.get('top_score', 0):.0%}")
            col_c.metric("Context density",   f"{conf_detail.get('density', 0):.0%}")
            if conf_detail.get("cov_penalty", 0):
                st.warning(f"Coverage penalty applied: −{conf_detail['cov_penalty']:.0%}")

    m = msg.get("pipeline_metrics", {})
    if m.get("total_ms", 0) > 0:
        with st.expander(f"⏱️ Pipeline — {m['total_ms']:.0f} ms total"):
            cols = st.columns(4)
            cols[0].metric("Retrieval", f"{m.get('retrieval_ms', 0):.0f} ms")
            cols[1].metric("LLM",       f"{m.get('llm_ms', 0):.0f} ms")
            cols[2].metric("Tokens",    m.get("total_tokens", 0))
            cols[3].metric("Chunks",    m.get("num_chunks_after_filter", 0))
            if m.get("query_expanded"):
                st.caption("✅ Query expansion improved retrieval recall.")

    _render_feedback(msg)


def _render_feedback(msg: dict) -> None:
    iid = msg.get("interaction_id")
    if not iid:
        return
    fkey = f"feedback_{iid}"
    if st.session_state.get(fkey) is None:
        col_a, col_b, _ = st.columns([1, 1, 6])
        if col_a.button("👍", key=f"helpful_{iid}",    help="Mark as helpful"):
            update_feedback(iid, "helpful");     st.session_state[fkey] = "helpful";     st.rerun()
        if col_b.button("👎", key=f"nothelpful_{iid}", help="Mark as not helpful"):
            update_feedback(iid, "not_helpful"); st.session_state[fkey] = "not_helpful"; st.rerun()
    else:
        recorded = st.session_state[fkey]
        st.caption("👍 Marked helpful" if recorded == "helpful" else "👎 Marked not helpful")


# ---------------------------------------------------------------------------
# Render conversation history
# ---------------------------------------------------------------------------
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg["role"] == "assistant":
            _render_assistant_meta(msg)

# ---------------------------------------------------------------------------
# Chat input
# ---------------------------------------------------------------------------
if raw_prompt := st.chat_input("Type your support question here…"):
    prompt = raw_prompt.strip()
    if not prompt:
        st.warning("Please type a question to continue.")
        st.stop()

    if len(prompt) > config.MAX_QUERY_LENGTH:
        prompt = prompt[:config.MAX_QUERY_LENGTH]

    st.session_state.messages.append({"role": "user", "content": raw_prompt})
    with st.chat_message("user"):
        st.markdown(raw_prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            vs      = st.session_state.vector_store
            history = format_for_prompt(st.session_state.history)
            metrics = PipelineMetrics(session_id=st.session_state.session_id)

            # --- Step 1: Classify ---
            with timed_stage(metrics, "classification"):
                classification = classify_query(prompt)

            query_type   = classification.get("category", "Other")
            is_off_topic = classification.get("is_off_topic", False)
            is_greeting  = classification.get("is_greeting", False)
            is_too_short = classification.get("is_too_short", False)

            # --- Step 2A: Too short ---
            if is_too_short:
                response_text = get_clarify_response()
                msg_type   = "clarify"
                sources    = []; confidence = 0.0; conf_detail = {}
                escalation = {"should_escalate": False, "severity": None, "priority": None,
                              "reasons": [], "recommended_action": "", "sla_deadline": None}

            # --- Step 2B: Greeting ---
            elif is_greeting:
                response_text = get_greeting_response()
                msg_type   = "greeting"; query_type = "Greeting"
                sources    = []; confidence = 0.0; conf_detail = {}
                escalation = {"should_escalate": False, "severity": None, "priority": None,
                              "reasons": [], "recommended_action": "", "sla_deadline": None}

            # --- Step 2C: Off-topic ---
            elif is_off_topic:
                st.session_state.off_topic_streak += 1
                streak = st.session_state.off_topic_streak
                response_text = get_redirect_message(streak)
                msg_type   = "off_topic"; query_type = "Off-Topic"
                sources    = []; confidence = 0.0; conf_detail = {}

                if streak >= 2:
                    escalation = {
                        "should_escalate": True, "severity": "HIGH", "priority": 2,
                        "reasons": [
                            f"Customer sent {streak} consecutive off-topic queries — "
                            "may need guidance or be confused about the service"
                        ],
                        "recommended_action": (
                            "Check in with the customer directly. They may be lost "
                            "or looking for a different type of support."
                        ),
                        "sla_deadline": sla_deadline("HIGH"),
                    }
                else:
                    escalation = {"should_escalate": False, "severity": None, "priority": None,
                                  "reasons": [], "recommended_action": "", "sla_deadline": None}

            # --- Step 2D: On-topic RAG ---
            else:
                st.session_state.off_topic_streak = 0
                msg_type = "rag"

                if vs is None:
                    result = generate_response_no_docs(prompt, history, metrics)
                else:
                    result = generate_response(
                        query=prompt, vector_store=vs,
                        conversation_history=history,
                        threshold=threshold, metrics=metrics,
                    )

                response_text = result["response"]
                sources       = result["sources"]
                confidence    = result["confidence"]
                conf_detail   = result.get("confidence_detail", {})
                metrics       = result.get("metrics", metrics)

                escalation = determine_escalation(
                    query=prompt, confidence_score=confidence,
                    is_sensitive_category=classification.get("is_sensitive", False),
                    query_category=query_type, threshold=threshold,
                )

                if result.get("no_docs_found") and vs is not None:
                    escalation["should_escalate"] = True
                    escalation["severity"] = escalation.get("severity") or "MEDIUM"
                    escalation["reasons"].append("No relevant documents found in knowledge base")

                metrics.escalated = escalation["should_escalate"]
                metrics.severity  = escalation.get("severity")
                metrics.priority  = escalation.get("priority")

            # --- Step 3: Render ---
            st.markdown(response_text)

            if msg_type == "greeting":
                st.caption("👋 Welcome message")

            elif msg_type == "clarify":
                st.caption("❓ Please clarify your question")

            elif msg_type == "off_topic":
                st.caption("↩️ Off-topic — redirected to support topics")
                if escalation["should_escalate"]:
                    st.error(
                        "🟠 **Escalated — Severity: HIGH**\n\n"
                        + "\n".join(f"- {r}" for r in escalation["reasons"])
                    )
                    st.info(f"**Recommended action:** {escalation['recommended_action']}")

            else:
                label = confidence_label(confidence, threshold)
                st.markdown(_confidence_badge_html(label, confidence), unsafe_allow_html=True)

                if escalation["should_escalate"]:
                    sev = escalation.get("severity", "")
                    st.error(
                        f"{SEVERITY_COLORS.get(sev, '⚠️')} **Escalated — Severity: {sev}**\n\n"
                        + "\n".join(f"- {r}" for r in escalation["reasons"])
                    )
                    if escalation.get("recommended_action"):
                        st.info(f"**Recommended action:** {escalation['recommended_action']}")

                if sources:
                    with st.expander(f"📚 Sources ({len(sources)} chunks)"):
                        for i, s in enumerate(sources, 1):
                            page_info = (
                                f", page {int(s['page']) + 1}" if s.get("page", "") != "" else ""
                            )
                            score_pct = f"{s.get('score', 0):.0%}"
                            st.markdown(
                                f"**{i}.** `{s['source']}{page_info}` — relevance: **{score_pct}**"
                            )

                if conf_detail and conf_detail.get("breakdown"):
                    with st.expander("🔬 Confidence breakdown"):
                        col_a, col_b, col_c = st.columns(3)
                        col_a.metric("Retrieval quality", f"{conf_detail.get('retrieval', 0):.0%}")
                        col_b.metric("Top-chunk score",   f"{conf_detail.get('top_score', 0):.0%}")
                        col_c.metric("Context density",   f"{conf_detail.get('density', 0):.0%}")
                        if conf_detail.get("cov_penalty", 0):
                            st.warning(f"Coverage penalty: −{conf_detail['cov_penalty']:.0%}")

                m = metrics.to_dict()
                if m.get("total_ms", 0) > 0:
                    with st.expander(f"⏱️ Pipeline — {m['total_ms']:.0f} ms total"):
                        cols = st.columns(4)
                        cols[0].metric("Retrieval", f"{m.get('retrieval_ms', 0):.0f} ms")
                        cols[1].metric("LLM",       f"{m.get('llm_ms', 0):.0f} ms")
                        cols[2].metric("Tokens",    m.get("total_tokens", 0))
                        cols[3].metric("Chunks",    m.get("num_chunks_after_filter", 0))
                        if m.get("query_expanded"):
                            st.caption("✅ Query expansion used.")

        # --- Step 4: Persist ---
        m_dict = metrics.to_dict() if msg_type == "rag" else {}

        iid = log_interaction(
            session_id=st.session_state.session_id,
            query=prompt, query_type=query_type,
            response=response_text,
            retrieved_context=(result.get("retrieved_context", "") if msg_type == "rag" else ""),
            sources=sources, confidence_score=confidence,
            escalated=escalation["should_escalate"],
            escalation_reasons=escalation["reasons"],
            severity=escalation.get("severity"),
            priority=escalation.get("priority"),
            total_latency_ms=m_dict.get("total_ms"),
            retrieval_latency_ms=m_dict.get("retrieval_ms"),
            llm_latency_ms=m_dict.get("llm_ms"),
            prompt_tokens=m_dict.get("prompt_tokens", 0),
            completion_tokens=m_dict.get("completion_tokens", 0),
            total_tokens=m_dict.get("total_tokens", 0),
            num_chunks=m_dict.get("num_chunks_after_filter", 0),
            avg_retrieval_score=m_dict.get("avg_retrieval_score", 0.0),
            query_expanded=m_dict.get("query_expanded", False),
            confidence_detail=conf_detail,
            request_id=m_dict.get("request_id", ""),
            sla_deadline=escalation.get("sla_deadline"),
            recommended_action=escalation.get("recommended_action", ""),
        )

        if msg_type in ("rag", "greeting"):
            st.session_state.history = add_turn(st.session_state.history, prompt, response_text)

        # --- Step 5: Save for UI re-render ---
        saved_msg = {
            "role": "assistant", "content": response_text,
            "msg_type": msg_type,
            "escalated": escalation["should_escalate"],
            "severity": escalation.get("severity"),
            "reasons": escalation["reasons"],
            "recommended_action": escalation.get("recommended_action", ""),
            "interaction_id": iid,
        }
        if msg_type == "rag":
            saved_msg.update({
                "sources": sources, "confidence": confidence,
                "confidence_detail": conf_detail,
                "pipeline_metrics": metrics.to_dict(),
            })
        st.session_state.messages.append(saved_msg)

        logger.info("interaction_complete", extra={
            "interaction_id": iid, "msg_type": msg_type,
            "query_type": query_type,
            "escalated": escalation["should_escalate"],
            "severity": escalation.get("severity"),
            "off_topic_streak": st.session_state.off_topic_streak,
        })

        st.rerun()
