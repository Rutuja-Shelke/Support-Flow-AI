# Demo Script

## AI-Powered Customer Support Workflow System

**Audience:** Product managers, engineering leads, support team managers  
**Duration:** ~15 minutes  
**Goal:** Demonstrate end-to-end workflow from document ingestion to human escalation

---

## Setup (Before Demo)

1. Start the app: `streamlit run app.py --server.port 5000`
2. Prepare 2–3 sample documents:
   - A returns/refund policy PDF
   - A product FAQ text file
   - A troubleshooting guide PDF
3. Have the browser open at `http://localhost:5000`

---

## Part 1 — Document Ingestion (2 minutes)

### Navigate to Documents page

1. Click **"📚 Documents"** in the sidebar
2. **Say:** "Before the AI can answer anything, it needs to know your company's policies and product information. We upload those as documents here."
3. Click "Choose files" and select your prepared documents
4. Click **"➕ Index selected files"**
5. Show the progress bar and chunk count
6. **Say:** "Each document is split into small chunks, embedded into a mathematical vector, and stored in a FAISS index — a highly efficient similarity search structure. This takes a few seconds and only needs to happen once per document."

---

## Part 2 — Normal Query (Happy Path) (3 minutes)

### Navigate to Chat page

1. Click **"Chat"** in the sidebar

### Query 1 — General FAQ (high confidence expected)

Type: `What is your return policy?`

**Point out:**
- 🟢 Green confidence badge (should be High or Medium)
- Source citations in the expandable panel — show the exact document and page
- Clean, concise answer grounded in your documents

**Say:** "Notice the source citations. Every claim in the answer is traceable to a specific page of a specific document. No hallucination is possible because the model is constrained to only use the retrieved context."

### Query 2 — Technical question

Type: `How do I reset my account password?`

**Point out:**
- Confidence score
- Multiple sources if retrieved from different docs
- Click the 👍 button — "Customers can give feedback on every response."

---

## Part 3 — Escalation Demo (5 minutes)

### Scenario A — Low confidence (no matching docs)

Type: `What are the terms of our enterprise SLA agreement?`

If this topic isn't in your documents:
- 🔴 Red confidence badge
- Escalation notice appears automatically
- **Say:** "Because the retrieval score is below the threshold, the system refuses to guess and escalates to a human agent. This is the core anti-hallucination mechanism."

### Scenario B — Sensitive keyword escalation

Type: `I want to sue your company for sending me a broken product`

**Point out:**
- Even if confidence is medium, the escalation fires
- Escalation reasons list will show "Sensitive keyword detected"
- **Say:** "Keywords like 'sue', 'fraud', 'chargeback' always trigger escalation regardless of confidence. You can customise this list in `src/config.py`."

### Scenario C — Explicit human request

Type: `Can I speak to a real person please?`

**Point out:**
- Instant escalation with reason "Customer explicitly requested a human agent"
- **Say:** "The system always respects an explicit request to talk to a human. The AI never tries to talk a customer out of speaking to a live agent."

### Confidence threshold demo

1. Move the sidebar slider from 0.60 to 0.80
2. Re-ask a borderline question
3. **Say:** "Support teams can tune the threshold in real time without restarting anything. Higher threshold means more escalations — appropriate for sensitive industries like finance or healthcare."

---

## Part 4 — Escalation Queue (3 minutes)

1. Navigate to **"🚨 Escalations"**
2. Show the open tickets from the demo queries
3. Expand a ticket — show the query, escalation reasons
4. Change status to `in_progress`, add a note: "Called customer back, processing refund"
5. Click Save
6. **Say:** "Human agents get a structured queue with all the context they need — the original question, why it was escalated, and a full history. They can update status and add notes as they resolve each case."

---

## Part 5 — Audit Logs (2 minutes)

1. Navigate to **"📋 Interaction Logs"**
2. Show the full table
3. Filter by "Escalated" — show only escalated interactions
4. Click on an interaction ID to expand it
5. Show the full retrieved context sent to the LLM
6. **Say:** "Every single interaction is logged — the query, response, confidence score, retrieved context, and feedback. This is your full compliance audit trail. You can export everything as CSV for analysis."

---

## Key Talking Points

### Why RAG instead of fine-tuning?

> "Fine-tuning bakes knowledge into the model weights — it can't cite sources and goes stale when your docs change. RAG retrieves at query time, always from your latest documents, and every answer is traceable to a specific chunk."

### Why escalate instead of just answer?

> "An overconfident wrong answer to a billing dispute costs you far more than a ticket that gets routed to a human. The system is calibrated to be honest about its own uncertainty."

### How does it prevent hallucinations?

> "Three layers: retrieval grounding (only document text reaches the model), a strict system prompt (answer only from context or say you don't know), and a coverage penalty that reduces the confidence score if the model signals uncertainty."

### Production readiness?

> "The vector store persists to disk across restarts. SQLite handles logging and the escalation queue. For higher scale, FAISS can be replaced with Pinecone or Weaviate, and SQLite with PostgreSQL — the interface layer in `src/vector_store.py` makes that swap straightforward."

---

## Frequently Asked Questions

**Q: Can it handle multiple languages?**  
A: Yes — both `text-embedding-3-small` and `gpt-4o-mini` are multilingual. Upload documents in the target language and queries in that language will work natively.

**Q: What happens when the API is down?**  
A: The app will display an error and won't serve a response. In production, wrap API calls with retry logic and a circuit breaker.

**Q: How do we update the knowledge base?**  
A: Upload the new document on the Documents page. Chunks are appended to the existing FAISS index. Old chunks from the same filename are not auto-removed — for a full refresh, clear the index and re-upload all documents.

**Q: Can we use a different LLM?**  
A: Yes — change `CHAT_MODEL` in `src/config.py`. The OpenAI client in `src/rag_engine.py` and `src/classifier.py` is the only integration point. Swap to any OpenAI-compatible endpoint (Azure OpenAI, local Ollama with OpenAI adapter, etc.).
