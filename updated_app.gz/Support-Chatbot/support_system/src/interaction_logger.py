"""
Interaction logger backed by SQLite.

Schema v2 — adds performance and severity columns while remaining
backward-compatible via ALTER TABLE migration on startup.

Tables
------
interactions  — one row per query/response exchange
escalations   — one row per escalation event (references interactions)
"""
import json
import sqlite3
from datetime import datetime
from typing import Optional

from src.config import DB_PATH


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")   # allow concurrent reads during writes
    return conn


def _add_column_if_missing(conn: sqlite3.Connection, table: str, col: str, col_type: str) -> None:
    """Idempotent column addition — safe to call on every startup."""
    existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
    if col not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_type}")


def init_db() -> None:
    """Create tables and migrate schema if needed."""
    conn = _connect()
    cur = conn.cursor()

    # Core tables
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS interactions (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id          TEXT    NOT NULL,
            timestamp           TEXT    NOT NULL,
            query               TEXT    NOT NULL,
            query_type          TEXT,
            response            TEXT,
            retrieved_context   TEXT,
            sources             TEXT,
            confidence_score    REAL,
            escalated           INTEGER DEFAULT 0,
            escalation_reason   TEXT,
            feedback            TEXT
        );

        CREATE TABLE IF NOT EXISTS escalations (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            interaction_id  INTEGER REFERENCES interactions(id),
            session_id      TEXT,
            timestamp       TEXT NOT NULL,
            query           TEXT,
            reasons         TEXT,
            status          TEXT DEFAULT 'open',
            agent_notes     TEXT
        );
    """)

    # ---- v2 migrations: new observability columns ----
    # interactions
    for col, typ in [
        ("total_latency_ms",    "REAL"),
        ("retrieval_latency_ms","REAL"),
        ("llm_latency_ms",      "REAL"),
        ("prompt_tokens",       "INTEGER"),
        ("completion_tokens",   "INTEGER"),
        ("total_tokens",        "INTEGER"),
        ("num_chunks",          "INTEGER"),
        ("avg_retrieval_score", "REAL"),
        ("query_expanded",      "INTEGER DEFAULT 0"),
        ("confidence_detail",   "TEXT"),
        ("severity",            "TEXT"),
        ("priority",            "INTEGER"),
        ("request_id",          "TEXT"),
    ]:
        _add_column_if_missing(conn, "interactions", col, typ)

    # escalations
    for col, typ in [
        ("severity",            "TEXT"),
        ("priority",            "INTEGER"),
        ("sla_deadline",        "TEXT"),
        ("recommended_action",  "TEXT"),
    ]:
        _add_column_if_missing(conn, "escalations", col, typ)

    # Indexes for common queries
    cur.executescript("""
        CREATE INDEX IF NOT EXISTS idx_interactions_session
            ON interactions(session_id);
        CREATE INDEX IF NOT EXISTS idx_interactions_escalated
            ON interactions(escalated);
        CREATE INDEX IF NOT EXISTS idx_escalations_status
            ON escalations(status);
        CREATE INDEX IF NOT EXISTS idx_escalations_priority
            ON escalations(priority);
    """)

    conn.commit()
    conn.close()


def log_interaction(
    session_id: str,
    query: str,
    query_type: str,
    response: str,
    retrieved_context: str,
    sources: list[dict],
    confidence_score: float,
    escalated: bool,
    escalation_reasons: list[str],
    # v2 fields
    severity: Optional[str] = None,
    priority: Optional[int] = None,
    total_latency_ms: Optional[float] = None,
    retrieval_latency_ms: Optional[float] = None,
    llm_latency_ms: Optional[float] = None,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    total_tokens: int = 0,
    num_chunks: int = 0,
    avg_retrieval_score: float = 0.0,
    query_expanded: bool = False,
    confidence_detail: Optional[dict] = None,
    request_id: str = "",
    sla_deadline: Optional[str] = None,
    recommended_action: str = "",
) -> int:
    """
    Insert one interaction record and, if escalated, a corresponding
    escalations record. Returns the interaction primary key.
    """
    conn = _connect()
    cur = conn.cursor()

    timestamp = datetime.utcnow().isoformat(timespec="seconds")
    sources_json = json.dumps(sources)
    reasons_str = "; ".join(escalation_reasons) if escalation_reasons else None
    conf_detail_json = json.dumps(confidence_detail) if confidence_detail else None

    cur.execute(
        """
        INSERT INTO interactions (
            session_id, timestamp, query, query_type, response,
            retrieved_context, sources, confidence_score,
            escalated, escalation_reason,
            total_latency_ms, retrieval_latency_ms, llm_latency_ms,
            prompt_tokens, completion_tokens, total_tokens,
            num_chunks, avg_retrieval_score, query_expanded,
            confidence_detail, severity, priority, request_id
        ) VALUES (
            ?, ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?,
            ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?
        )
        """,
        (
            session_id, timestamp, query, query_type, response,
            retrieved_context, sources_json, confidence_score,
            int(escalated), reasons_str,
            total_latency_ms, retrieval_latency_ms, llm_latency_ms,
            prompt_tokens, completion_tokens, total_tokens,
            num_chunks, avg_retrieval_score, int(query_expanded),
            conf_detail_json, severity, priority, request_id,
        ),
    )
    interaction_id = cur.lastrowid

    if escalated:
        cur.execute(
            """
            INSERT INTO escalations (
                interaction_id, session_id, timestamp, query, reasons,
                severity, priority, sla_deadline, recommended_action
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                interaction_id, session_id, timestamp, query, reasons_str,
                severity, priority, sla_deadline, recommended_action,
            ),
        )

    conn.commit()
    conn.close()
    return interaction_id


def update_feedback(interaction_id: int, feedback: str) -> None:
    conn = _connect()
    conn.execute(
        "UPDATE interactions SET feedback = ? WHERE id = ?",
        (feedback, interaction_id),
    )
    conn.commit()
    conn.close()


def get_all_interactions(limit: int = 200) -> list[dict]:
    conn = _connect()
    rows = conn.execute(
        "SELECT * FROM interactions ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_escalations(limit: int = 500) -> list[dict]:
    """Return escalations sorted by priority (CRITICAL first), then timestamp."""
    conn = _connect()
    rows = conn.execute(
        """
        SELECT * FROM escalations
        ORDER BY
            CASE WHEN status='resolved' THEN 1 ELSE 0 END ASC,
            COALESCE(priority, 99) ASC,
            id DESC
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_escalation_status(escalation_id: int, status: str, notes: str = "") -> None:
    conn = _connect()
    conn.execute(
        "UPDATE escalations SET status = ?, agent_notes = ? WHERE id = ?",
        (status, notes, escalation_id),
    )
    conn.commit()
    conn.close()


def get_stats() -> dict:
    conn = _connect()
    total = conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0]
    escalated = conn.execute(
        "SELECT COUNT(*) FROM interactions WHERE escalated = 1"
    ).fetchone()[0]
    helpful = conn.execute(
        "SELECT COUNT(*) FROM interactions WHERE feedback = 'helpful'"
    ).fetchone()[0]
    not_helpful = conn.execute(
        "SELECT COUNT(*) FROM interactions WHERE feedback = 'not_helpful'"
    ).fetchone()[0]
    open_escalations = conn.execute(
        "SELECT COUNT(*) FROM escalations WHERE status = 'open'"
    ).fetchone()[0]

    # v2 stats
    avg_conf = conn.execute(
        "SELECT AVG(confidence_score) FROM interactions WHERE confidence_score IS NOT NULL"
    ).fetchone()[0]
    avg_latency = conn.execute(
        "SELECT AVG(total_latency_ms) FROM interactions WHERE total_latency_ms > 0"
    ).fetchone()[0]

    # Severity breakdown for open escalations
    sev_counts: dict[str, int] = {}
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        count = conn.execute(
            "SELECT COUNT(*) FROM escalations WHERE status != 'resolved' AND severity = ?",
            (sev,),
        ).fetchone()[0]
        sev_counts[sev.lower()] = count

    conn.close()

    return {
        "total": total,
        "escalated": escalated,
        "helpful": helpful,
        "not_helpful": not_helpful,
        "open_escalations": open_escalations,
        "avg_confidence": round(avg_conf or 0, 3),
        "avg_latency_ms": round(avg_latency or 0, 1),
        **{f"sev_{k}": v for k, v in sev_counts.items()},
    }


def get_latency_series(limit: int = 100) -> list[dict]:
    """Return recent latency data for the performance chart."""
    conn = _connect()
    rows = conn.execute(
        """
        SELECT timestamp, total_latency_ms, retrieval_latency_ms, llm_latency_ms
        FROM interactions
        WHERE total_latency_ms > 0
        ORDER BY id DESC LIMIT ?
        """,
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]


def get_confidence_series(limit: int = 100) -> list[float]:
    """Return recent confidence scores for histogram."""
    conn = _connect()
    rows = conn.execute(
        "SELECT confidence_score FROM interactions WHERE confidence_score IS NOT NULL ORDER BY id DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [r[0] for r in rows]
