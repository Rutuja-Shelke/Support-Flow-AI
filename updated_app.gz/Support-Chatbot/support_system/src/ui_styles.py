"""
Shared UI styling — injected into every Streamlit page.
Provides a modern, enterprise-grade aesthetic while staying lightweight.
"""

APP_CSS = """
<style>
/* ── Typography ─────────────────────────────────────────────────────────── */
html, body, .stApp {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui,
                 "Helvetica Neue", Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
}

h1 { font-weight: 700; letter-spacing: -0.02em; color: #0f172a; }
h2, h3 { font-weight: 600; color: #1e293b; }

/* ── Sidebar ─────────────────────────────────────────────────────────────── */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
    border-right: 1px solid #334155;
}
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] small {
    color: #cbd5e1 !important;
}
section[data-testid="stSidebar"] h1,
section[data-testid="stSidebar"] h2,
section[data-testid="stSidebar"] h3 {
    color: #f1f5f9 !important;
}
section[data-testid="stSidebar"] hr {
    border-color: #334155 !important;
    margin: 12px 0;
}
section[data-testid="stSidebar"] [data-testid="metric-container"] {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 10px 14px;
}
section[data-testid="stSidebar"] [data-testid="metric-container"] label {
    color: #94a3b8 !important;
    font-size: 12px;
}
section[data-testid="stSidebar"] [data-testid="metric-container"] [data-testid="stMetricValue"] {
    color: #f1f5f9 !important;
    font-size: 20px;
    font-weight: 700;
}

/* ── Metric cards (main content) ─────────────────────────────────────────── */
.main [data-testid="metric-container"] {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 16px 20px;
    transition: box-shadow 0.15s ease;
}
.main [data-testid="metric-container"]:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.06);
}

/* ── Chat messages ───────────────────────────────────────────────────────── */
[data-testid="stChatMessage"] {
    border-radius: 14px;
    padding: 4px 2px;
    margin-bottom: 4px;
}
[data-testid="stChatMessage"][data-testid*="user"] {
    background: #f0f9ff;
}

/* Chat input */
[data-testid="stChatInput"] {
    border-radius: 12px !important;
    border: 1.5px solid #e2e8f0 !important;
    background: #fff !important;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    transition: border-color 0.15s;
}
[data-testid="stChatInput"]:focus-within {
    border-color: #3b82f6 !important;
    box-shadow: 0 0 0 3px rgba(59,130,246,0.12);
}

/* ── Buttons ─────────────────────────────────────────────────────────────── */
.stButton > button {
    border-radius: 8px !important;
    font-weight: 500 !important;
    letter-spacing: 0.01em;
    transition: all 0.15s ease;
}
.stButton > button[kind="primary"] {
    background: #2563eb !important;
    border: none !important;
    color: #fff !important;
    font-weight: 600 !important;
}
.stButton > button[kind="primary"]:hover {
    background: #1d4ed8 !important;
    box-shadow: 0 4px 12px rgba(37,99,235,0.3);
    transform: translateY(-1px);
}
.stButton > button:not([kind="primary"]):hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

/* ── Alert boxes ─────────────────────────────────────────────────────────── */
.stAlert {
    border-radius: 10px !important;
    border-width: 1px !important;
}
[data-testid="stNotification"] {
    border-radius: 10px;
}

/* ── Expanders ───────────────────────────────────────────────────────────── */
details {
    border-radius: 10px !important;
    border: 1px solid #e5e7eb !important;
    overflow: hidden;
}
summary {
    font-weight: 500;
    color: #374151;
    background: #f9fafb;
    padding: 10px 14px;
}
summary:hover {
    background: #f3f4f6;
}

/* ── Dividers ────────────────────────────────────────────────────────────── */
hr {
    border: none;
    border-top: 1px solid #f1f5f9;
    margin: 20px 0;
}

/* ── DataFrames ──────────────────────────────────────────────────────────── */
[data-testid="stDataFrame"] {
    border-radius: 10px;
    overflow: hidden;
    border: 1px solid #e5e7eb;
}

/* ── Progress bars ───────────────────────────────────────────────────────── */
.stProgress > div > div {
    border-radius: 99px;
    background: linear-gradient(90deg, #3b82f6, #2563eb);
}

/* ── Spinner ─────────────────────────────────────────────────────────────── */
[data-testid="stSpinner"] > div {
    border-top-color: #3b82f6 !important;
}

/* ── Select / input ──────────────────────────────────────────────────────── */
.stSelectbox > div > div,
.stTextInput > div > div > input {
    border-radius: 8px !important;
    border-color: #d1d5db !important;
}

/* ── Tab bar ─────────────────────────────────────────────────────────────── */
.stTabs [data-baseweb="tab-list"] {
    gap: 8px;
    border-bottom: 2px solid #f1f5f9;
    padding-bottom: 0;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px 8px 0 0;
    font-weight: 500;
    padding: 8px 16px;
}
.stTabs [aria-selected="true"] {
    background: #eff6ff;
    color: #2563eb !important;
    border-bottom: 2px solid #2563eb;
}

/* ── Caption / small text ────────────────────────────────────────────────── */
.stCaption {
    color: #6b7280;
    font-size: 13px;
}

/* ── Slider ──────────────────────────────────────────────────────────────── */
[data-testid="stSlider"] [data-testid="stThumbValue"] {
    color: #2563eb;
    font-weight: 600;
}

/* ── Code inline ─────────────────────────────────────────────────────────── */
code {
    background: #f1f5f9;
    border-radius: 5px;
    padding: 2px 6px;
    font-size: 0.88em;
    color: #1e293b;
}
</style>
"""


def inject_css() -> None:
    """Inject shared CSS into the current Streamlit page."""
    import streamlit as st
    st.markdown(APP_CSS, unsafe_allow_html=True)
