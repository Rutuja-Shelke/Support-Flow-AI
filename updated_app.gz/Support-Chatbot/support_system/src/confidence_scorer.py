"""
Multi-dimensional confidence scoring module.

Confidence is computed from four independent signals:
  1. Retrieval quality    — rank-weighted average of FAISS similarity scores
  2. Top-score bonus      — rewards very high relevance for the best chunk
  3. Context density      — fraction of retrieved chunks above the min threshold
  4. Coverage check       — LLM explicitly signalled it couldn't answer → penalty
  5. Brevity check        — suspiciously short response → small penalty

The final score is in [0, 1]. A breakdown dict is also returned for
the observability dashboard.
"""

from src.config import (
    CONF_BREVITY_PENALTY,
    CONF_COVERAGE_PENALTY,
    CONF_WEIGHT_DENSITY,
    CONF_WEIGHT_RETRIEVAL,
    CONF_WEIGHT_TOP_SCORE,
    DEFAULT_CONFIDENCE_THRESHOLD,
    MIN_RELEVANCE_SCORE,
)

# Phrases that indicate the LLM could not fully answer from context
_UNCERTAINTY_PHRASES: list[str] = [
    "i don't have enough information",
    "not in my knowledge base",
    "i cannot find",
    "i'm not sure",
    "i don't know",
    "unable to find",
    "no information available",
    "i cannot answer",
    "outside of my knowledge",
    "not covered in",
]

# Minimum response length (chars) before the brevity penalty kicks in
_BREVITY_THRESHOLD: int = 80


# ---------------------------------------------------------------------------
# Individual signal functions
# ---------------------------------------------------------------------------

def _rank_weighted_score(scores: list[float]) -> float:
    """
    Weighted average of retrieval scores using a harmonic-rank decay.
    Rank 1 → weight 1.0, rank 2 → 0.50, rank 3 → 0.33, …
    """
    if not scores:
        return 0.0
    weights = [1.0 / (i + 1) for i in range(len(scores))]
    return sum(s * w for s, w in zip(scores, weights)) / sum(weights)


def _top_score_component(scores: list[float]) -> float:
    """
    Return the best-chunk score normalised so that scores above 0.8
    push the component towards 1.0 and scores below 0.4 give near-zero.
    Uses a soft sigmoid-like rescaling.
    """
    if not scores:
        return 0.0
    top = max(scores)
    # Rescale [0.0, 1.0] → emphasise the high end
    return min(1.0, max(0.0, (top - 0.20) / 0.70))


def _density_score(scores: list[float]) -> float:
    """
    Fraction of retrieved chunks with score ≥ MIN_RELEVANCE_SCORE.
    Rewards cases where many chunks are relevant (broad coverage).
    """
    if not scores:
        return 0.0
    above = sum(1 for s in scores if s >= MIN_RELEVANCE_SCORE)
    return above / len(scores)


def _coverage_penalty(response_text: str) -> float:
    """Return CONF_COVERAGE_PENALTY if the response signals uncertainty."""
    lower = response_text.lower()
    for phrase in _UNCERTAINTY_PHRASES:
        if phrase in lower:
            return CONF_COVERAGE_PENALTY
    return 0.0


def _brevity_penalty(response_text: str) -> float:
    """Return CONF_BREVITY_PENALTY for responses that are suspiciously short."""
    if len(response_text.strip()) < _BREVITY_THRESHOLD:
        return CONF_BREVITY_PENALTY
    return 0.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def score_response(
    retrieval_scores: list[float],
    response_text: str,
) -> float:
    """
    Backward-compatible single-value confidence score.
    Delegates to score_response_detailed and returns only the scalar.
    """
    return score_response_detailed(retrieval_scores, response_text)["score"]


def score_response_detailed(
    retrieval_scores: list[float],
    response_text: str,
) -> dict:
    """
    Compute the full multi-dimensional confidence score.

    Returns:
        {
          "score":         float — final confidence in [0, 1]
          "retrieval":     float — rank-weighted retrieval component
          "top_score":     float — top-chunk bonus component
          "density":       float — context density component
          "cov_penalty":   float — coverage penalty applied
          "brev_penalty":  float — brevity penalty applied
          "breakdown":     str   — human-readable formula trace
        }
    """
    r = _rank_weighted_score(retrieval_scores)
    t = _top_score_component(retrieval_scores)
    d = _density_score(retrieval_scores)
    cov = _coverage_penalty(response_text)
    brev = _brevity_penalty(response_text)

    base = (
        CONF_WEIGHT_RETRIEVAL * r
        + CONF_WEIGHT_TOP_SCORE * t
        + CONF_WEIGHT_DENSITY * d
    )
    final = round(max(0.0, min(1.0, base - cov - brev)), 4)

    breakdown = (
        f"base={base:.3f} "
        f"(ret={r:.2f}×{CONF_WEIGHT_RETRIEVAL} + "
        f"top={t:.2f}×{CONF_WEIGHT_TOP_SCORE} + "
        f"den={d:.2f}×{CONF_WEIGHT_DENSITY}) "
        f"− cov={cov} − brev={brev} → {final}"
    )

    return {
        "score": final,
        "retrieval": round(r, 4),
        "top_score": round(t, 4),
        "density": round(d, 4),
        "cov_penalty": cov,
        "brev_penalty": brev,
        "breakdown": breakdown,
    }


def confidence_label(
    score: float, threshold: float = DEFAULT_CONFIDENCE_THRESHOLD
) -> str:
    """Human-readable label for a confidence score."""
    if score >= 0.80:
        return "High"
    elif score >= threshold:
        return "Medium"
    else:
        return "Low"


def should_escalate_on_confidence(
    score: float, threshold: float = DEFAULT_CONFIDENCE_THRESHOLD
) -> bool:
    return score < threshold
