"""
FAISS vector store management.

Embeddings: sentence-transformers/all-MiniLM-L6-v2 (local, free, 384-dim)
No external API calls — embeddings run entirely on CPU.
"""
import os
from functools import lru_cache

from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS

from src.config import EMBEDDING_MODEL, VECTOR_STORE_PATH


@lru_cache(maxsize=1)
def _get_embeddings():
    """
    Return a cached HuggingFaceEmbeddings instance.
    Model is downloaded once and reused for all calls.
    """
    try:
        from langchain_huggingface import HuggingFaceEmbeddings
    except ImportError:
        from langchain_community.embeddings import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def create_vector_store(documents: list[Document]) -> FAISS:
    """Build a new FAISS index from a list of Document chunks."""
    embeddings = _get_embeddings()
    store = FAISS.from_documents(documents, embeddings)
    return store


def save_vector_store(store: FAISS, path: str = VECTOR_STORE_PATH) -> None:
    """Persist the FAISS index to disk."""
    os.makedirs(path, exist_ok=True)
    store.save_local(path)


def load_vector_store(path: str = VECTOR_STORE_PATH) -> FAISS | None:
    """
    Load a previously saved FAISS index from disk.
    Returns None if no saved index exists.
    """
    index_file = os.path.join(path, "index.faiss")
    if not os.path.exists(index_file):
        return None

    embeddings = _get_embeddings()
    try:
        store = FAISS.load_local(
            path, embeddings, allow_dangerous_deserialization=True
        )
        return store
    except Exception:
        # Index was built with a different embedding model — wipe it
        import shutil
        shutil.rmtree(path, ignore_errors=True)
        return None


def add_documents(store: FAISS, documents: list[Document]) -> FAISS:
    """Merge new documents into an existing FAISS store."""
    store.add_documents(documents)
    return store


def similarity_search(
    store: FAISS, query: str, k: int = 5
) -> list[tuple[Document, float]]:
    """Run similarity search; returns (Document, score) pairs in [0,1]."""
    return store.similarity_search_with_relevance_scores(query, k=k)
