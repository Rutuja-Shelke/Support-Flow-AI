"""
Document ingestion pipeline.

Supports PDF and plain-text files. Each file is loaded, split into
overlapping chunks, and returned as a list of LangChain Document objects
ready to be embedded and stored in the vector database.
"""
import os
import tempfile
from typing import Union

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader

from src.config import CHUNK_SIZE, CHUNK_OVERLAP


def _make_splitter() -> RecursiveCharacterTextSplitter:
    """Return a text splitter with the project-wide chunk settings."""
    return RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],
    )


def load_pdf(file_bytes: bytes, filename: str) -> list[Document]:
    """
    Load a PDF from raw bytes, split into chunks, and return Documents.
    Metadata includes the source filename and page number.
    """
    splitter = _make_splitter()

    # PyPDFLoader needs a real file path, so we write to a temp file
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(file_bytes)
        tmp_path = tmp.name

    try:
        loader = PyPDFLoader(tmp_path)
        pages = loader.load()

        # Attach a human-readable source name to every page
        for page in pages:
            page.metadata["source"] = filename

        chunks = splitter.split_documents(pages)
    finally:
        os.unlink(tmp_path)

    return chunks


def load_text(file_bytes: bytes, filename: str) -> list[Document]:
    """
    Load a plain-text file from raw bytes, split into chunks, and return
    Documents. Works for .txt and .md files.
    """
    splitter = _make_splitter()
    content = file_bytes.decode("utf-8", errors="replace")

    doc = Document(page_content=content, metadata={"source": filename, "page": 0})
    chunks = splitter.split_documents([doc])
    return chunks


def process_uploaded_file(
    file_bytes: bytes, filename: str
) -> tuple[list[Document], str]:
    """
    Dispatch to the correct loader based on file extension.

    Returns:
        (chunks, message) — chunks is a list of Document objects;
        message describes the outcome.
    """
    ext = os.path.splitext(filename)[1].lower()

    if ext == ".pdf":
        chunks = load_pdf(file_bytes, filename)
        msg = f"Loaded **{filename}** — {len(chunks)} chunks extracted from PDF."
    elif ext in (".txt", ".md"):
        chunks = load_text(file_bytes, filename)
        msg = f"Loaded **{filename}** — {len(chunks)} chunks extracted from text."
    else:
        return [], f"Unsupported file type: `{ext}`. Please upload PDF or TXT/MD files."

    return chunks, msg
