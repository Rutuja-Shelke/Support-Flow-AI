"""
Escalation handler — severity-aware, SLA-tracked escalation engine.

Every escalation is assigned:
  - Severity  : CRITICAL / HIGH / MEDIUM / LOW
  - Priority  : 1 (highest) – 4 (lowest) — used to sort the agent queue
  - SLA       : deadline timestamp based on severity
  - Action    : recommended resolution path for the human agent

Escalation triggers (any one fires escalation):
  1. CRITICAL keyword in the query  → CRITICAL severity
  2. Explicit human-agent request   → HIGH severity
  3. HIGH keyword in the query      → HIGH severity
  4. Sensitive category (Legal / Security) → HIGH severity
  5. Sensitive category (Complaint) → MEDIUM severity
  6. Confidence below threshold     → LOW severity
  7. MEDIUM keyword + low confidence → MEDIUM severity
"""
from datetime import datetime, timedelta
from typing import Optional

from src.config import (
    CRITICAL_KEYWORDS,
    DEFAULT_CONFIDENCE_THRESHOLD,
    ESCALATION_RECOMMENDED_ACTIONS,
    ESCALATION_SLA_HOURS,
    HIGH_KEYWORDS,
    HUMAN_REQUEST_PHRASES,
    MEDIUM_KEYWORDS,
)

# Priority map: lower = more urgent
_SEVERITY_PRIORITY: dict[str, int] = {
    "CRITICAL": 1,
    "HIGH": 2,
    "MEDIUM": 3,
    "LOW": 4,
}


# ---------------------------------------------------------------------------
# Internal signal detectors
# ---------------------------------------------------------------------------

def _matches(text: str, phrases: list[str]) -> list[str]:
    """Return the subset of phrases found in text (case-insensitive)."""
    lower = text.lower()
    return [p for p in phrases if p in lower]


def _check_human_request(query: str) -> Optional[str]:
    hits = _matches(query, HUMAN_REQUEST_PHRASES)
    return hits[0] if hits else None


def _check_critical(query: str) -> Optional[str]:
    hits = _matches(query, CRITICAL_KEYWORDS)
    return hits[0] if hits else None


def _check_high(query: str) -> Optional[str]:
    hits = _matches(query, HIGH_KEYWORDS)
    return hits[0] if hits else None


def _check_medium(query: str) -> Optional[str]:
    hits = _matches(query, MEDIUM_KEYWORDS)
    return hits[0] if hits else None


# ---------------------------------------------------------------------------
# SLA helper
# ---------------------------------------------------------------------------

def sla_deadline(severity: str) -> str:
    """Return an ISO-formatted UTC deadline timestamp for the given severity."""
    hours = ESCALATION_SLA_HOURS.get(severity, 48)
    deadline = datetime.utcnow() + timedelta(hours=hours)
    return deadline.isoformat(timespec="seconds")


def sla_remaining(deadline_iso: str) -> str:
    """
    Return a human-readable remaining time string for the given deadline.
    Returns "Overdue" if the deadline has passed.
    """
    try:
        deadline = datetime.fromisoformat(deadline_iso)
        delta = deadline - datetime.utcnow()
        if delta.total_seconds() <= 0:
            return "🔴 Overdue"
        hours = int(delta.total_seconds() // 3600)
        minutes = int((delta.total_seconds() % 3600) // 60)
        if hours > 24:
            days = hours // 24
            return f"🟢 {days}d {hours % 24}h remaining"
        elif hours > 4:
            return f"🟡 {hours}h {minutes}m remaining"
        else:
            return f"🔴 {hours}h {minutes}m remaining"
    except Exception:
        return "Unknown"


# ---------------------------------------------------------------------------
# Main API
# ---------------------------------------------------------------------------

def determine_escalation(
    query: str,
    confidence_score: float,
    is_sensitive_category: bool,
    query_category: str = "Other",
    threshold: float = DEFAULT_CONFIDENCE_THRESHOLD,
) -> dict:
    """
    Decide whether to escalate and at what severity.

    Returns:
        {
          "should_escalate": bool,
          "severity":        str | None,  # CRITICAL/HIGH/MEDIUM/LOW
          "priority":        int | None,  # 1–4
          "reasons":         list[str],
          "recommended_action": str,
          "sla_deadline":    str | None,  # ISO timestamp
        }
    """
    reasons: list[str] = []
    severity: Optional[str] = None

    # ---- Tier 1: CRITICAL ----
    crit_kw = _check_critical(query)
    if crit_kw:
        severity = "CRITICAL"
        reasons.append(f"Critical keyword detected: '{crit_kw}'")

    # ---- Tier 2: HIGH ----
    if severity is None:
        human_phrase = _check_human_request(query)
        high_kw = _check_high(query)

        if human_phrase:
            severity = "HIGH"
            reasons.append(f"Customer explicitly requested a human agent")
        elif high_kw:
            severity = "HIGH"
            reasons.append(f"High-risk keyword detected: '{high_kw}'")
        elif query_category in ("Legal", "Security"):
            severity = "HIGH"
            reasons.append(f"Query classified as sensitive category: {query_category}")

    # ---- Tier 3: MEDIUM ----
    if severity is None:
        med_kw = _check_medium(query)
        if query_category == "Complaint":
            severity = "MEDIUM"
            reasons.append("Query classified as Complaint")
        elif med_kw and confidence_score < threshold:
            severity = "MEDIUM"
            reasons.append(f"Dissatisfaction keyword ('{med_kw}') combined with low confidence")
        elif is_sensitive_category:
            severity = "MEDIUM"
            reasons.append("Sensitive topic requires human verification")

    # ---- Tier 4: LOW (confidence-only) ----
    if severity is None and confidence_score < threshold:
        severity = "LOW"
        reasons.append(
            f"AI confidence too low ({confidence_score:.0%} < {threshold:.0%} threshold) "
            f"— human verification required"
        )

    # ---- Build result ----
    should_escalate = severity is not None
    priority = _SEVERITY_PRIORITY.get(severity) if severity else None
    deadline = sla_deadline(severity) if severity else None
    action = ESCALATION_RECOMMENDED_ACTIONS.get(severity, "") if severity else ""

    return {
        "should_escalate": should_escalate,
        "severity": severity,
        "priority": priority,
        "reasons": reasons,
        "recommended_action": action,
        "sla_deadline": deadline,
    }


def format_escalation_summary(escalation: dict) -> str:
    """Return a short Markdown string summarising the escalation decision."""
    if not escalation.get("should_escalate"):
        return ""

    sev = escalation.get("severity", "")
    lines = [f"**⚠️ Escalated — Severity: {sev}**\n"]
    for reason in escalation.get("reasons", []):
        lines.append(f"- {reason}")
    action = escalation.get("recommended_action", "")
    if action:
        lines.append(f"\n*Recommended action:* {action}")
    return "\n".join(lines)


SEVERITY_COLORS: dict[str, str] = {
    "CRITICAL": "🔴",
    "HIGH": "🟠",
    "MEDIUM": "🟡",
    "LOW": "🔵",
}
