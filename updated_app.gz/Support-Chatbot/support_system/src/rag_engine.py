"""
RAG (Retrieval-Augmented Generation) engine — Google Gemini 1.5 Flash (google-genai SDK).

Pipeline:
  1. Query expansion   — generate alternative phrasings (Gemini)
  2. Retrieval         — MMR + multi-query merge (FAISS + sentence-transformers)
  3. Context assembly  — deduplicated, score-filtered chunks
  4. LLM answer        — grounded response from Gemini
  5. Confidence score  — multi-dimensional scoring
"""
import hashlib
import time
from typing import Optional

from google import genai
from google.genai import types

from src.config import (
    CHAT_MODEL, GEMINI_API_KEY, LLM_MAX_RETRIES, LLM_RETRY_WAIT_SECONDS,
    MIN_RELEVANCE_SCORE, MMR_FETCH_K, MMR_LAMBDA, QUERY_EXPANSION_COUNT,
    QUERY_EXPANSION_ENABLED, SYSTEM_PROMPT, TOP_K_CHUNKS,
)
from src.confidence_scorer import score_response_detailed
from src.observability import PipelineMetrics, get_logger, timed_stage

logger = get_logger("rag_engine")


# ---------------------------------------------------------------------------
# Gemini client helper
# ---------------------------------------------------------------------------

def _get_client() -> genai.Client:
    return genai.Client(api_key=GEMINI_API_KEY)


def _to_gemini_contents(messages: list[dict]) -> list[types.Content]:
    """
    Convert OpenAI-format messages to Gemini Content objects.
    - System messages are skipped (passed separately as system_instruction)
    - "assistant" role → "model"
    """
    contents = []
    for msg in messages:
        role = msg["role"]
        if role == "system":
            continue
        if role == "assistant":
            role = "model"
        contents.append(
            types.Content(role=role, parts=[types.Part(text=msg["content"])])
        )
    return contents


def _gemini_call(
    messages: list[dict],
    system_instruction: str = "",
    max_tokens: int = 1024,
    temperature: float = 0.2,
) -> types.GenerateContentResponse:
    """
    Call Gemini with retry/backoff on rate-limit and transient errors.
    messages should be in OpenAI format; system messages are extracted automatically.
    """
    client = _get_client()
    contents = _to_gemini_contents(messages)
    cfg = types.GenerateContentConfig(
        system_instruction=system_instruction if system_instruction else None,
        temperature=temperature,
        max_output_tokens=max_tokens,
    )

    last_err: Optional[Exception] = None
    for attempt in range(1, LLM_MAX_RETRIES + 1):
        try:
            return client.models.generate_content(
                model=CHAT_MODEL,
                contents=contents,
                config=cfg,
            )
        except Exception as e:
            last_err = e
            err_str = str(e).lower()
            if "quota" in err_str or "rate" in err_str or "429" in err_str:
                wait = LLM_RETRY_WAIT_SECONDS * (2 ** (attempt - 1))
                logger.warning("Gemini rate-limited (attempt %d/%d), waiting %.1fs",
                               attempt, LLM_MAX_RETRIES, wait)
                time.sleep(wait)
            elif attempt < LLM_MAX_RETRIES:
                time.sleep(LLM_RETRY_WAIT_SECONDS)
            else:
                break

    raise RuntimeError(f"Gemini call failed after {LLM_MAX_RETRIES} attempts: {last_err}")


def _extract_tokens(response: types.GenerateContentResponse) -> tuple[int, int, int]:
    """Extract (prompt, completion, total) token counts from a Gemini response."""
    um = getattr(response, "usage_metadata", None)
    if not um:
        return 0, 0, 0
    return (
        getattr(um, "prompt_token_count", 0) or 0,
        getattr(um, "candidates_token_count", 0) or 0,
        getattr(um, "total_token_count", 0) or 0,
    )


# ---------------------------------------------------------------------------
# Query expansion
# ---------------------------------------------------------------------------

def _expand_query(query: str, n: int = QUERY_EXPANSION_COUNT) -> list[str]:
    """Generate alternative phrasings to improve retrieval recall."""
    prompt = (
        f"Generate {n} short alternative phrasings of this customer support query. "
        "Capture the same intent with different words. "
        "Output one phrasing per line, no numbering, no explanations.\n\n"
        f"Query: {query}"
    )
    try:
        client = _get_client()
        resp = client.models.generate_content(
            model=CHAT_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(temperature=0.7, max_output_tokens=150),
        )
        lines = [ln.strip() for ln in resp.text.splitlines() if ln.strip()]
        return lines[:n]
    except Exception as e:
        logger.warning("Query expansion failed: %s", e)
        return []


# ---------------------------------------------------------------------------
# Retrieval helpers
# ---------------------------------------------------------------------------

def _retrieve_with_mmr(vector_store, query: str, k: int = TOP_K_CHUNKS) -> list[tuple]:
    try:
        mmr_docs = vector_store.max_marginal_relevance_search(
            query, k=k, fetch_k=MMR_FETCH_K, lambda_mult=MMR_LAMBDA
        )
        scored_all = vector_store.similarity_search_with_relevance_scores(query, k=MMR_FETCH_K)
        score_map = {
            hashlib.md5(doc.page_content[:200].encode()).hexdigest(): score
            for doc, score in scored_all
        }
        result = []
        for doc in mmr_docs:
            h = hashlib.md5(doc.page_content[:200].encode()).hexdigest()
            score = score_map.get(h, MIN_RELEVANCE_SCORE)
            if score >= MIN_RELEVANCE_SCORE:
                result.append((doc, score))
        return result
    except Exception:
        return [
            (doc, score)
            for doc, score in vector_store.similarity_search_with_relevance_scores(query, k=k)
            if score >= MIN_RELEVANCE_SCORE
        ]


def _multi_query_retrieve(
    vector_store, query: str, expansions: list[str], k: int = TOP_K_CHUNKS
) -> list[tuple]:
    seen: dict[str, tuple] = {}
    all_queries = [query] + expansions
    per_q_k = max(3, k // len(all_queries) + 1)
    for q in all_queries:
        try:
            for doc, score in _retrieve_with_mmr(vector_store, q, k=per_q_k):
                h = hashlib.md5(doc.page_content[:200].encode()).hexdigest()
                if h not in seen or score > seen[h][1]:
                    seen[h] = (doc, score)
        except Exception as e:
            logger.warning("Retrieval failed for query '%s…': %s", q[:40], e)
    return sorted(seen.values(), key=lambda x: x[1], reverse=True)[:k]


def _build_context_block(docs_with_scores: list) -> tuple[str, list[dict], list[float]]:
    context_parts, sources, scores = [], [], []
    for i, (doc, score) in enumerate(docs_with_scores, start=1):
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", "")
        page_str = f", page {int(page) + 1}" if page != "" else ""
        content = doc.page_content.strip()[:700]
        context_parts.append(f"[Source {i}: {source}{page_str}]\n{content}")
        sources.append({"source": source, "page": page, "score": round(score, 3)})
        scores.append(score)
    return "\n\n---\n\n".join(context_parts), sources, scores


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def generate_response(
    query: str,
    vector_store,
    conversation_history: list[dict],
    threshold: float = 0.60,
    metrics: Optional[PipelineMetrics] = None,
) -> dict:
    """Full RAG pipeline. Returns response, sources, confidence, and metrics."""
    if metrics is None:
        metrics = PipelineMetrics()

    pipeline_start = time.perf_counter()

    # 1. Query expansion
    expansions: list[str] = []
    if QUERY_EXPANSION_ENABLED:
        with timed_stage(metrics, "expansion"):
            expansions = _expand_query(query, QUERY_EXPANSION_COUNT)
            metrics.query_expanded = bool(expansions)

    # 2. Retrieval
    with timed_stage(metrics, "retrieval"):
        if expansions:
            docs_with_scores = _multi_query_retrieve(vector_store, query, expansions, TOP_K_CHUNKS)
        else:
            docs_with_scores = _retrieve_with_mmr(vector_store, query, TOP_K_CHUNKS)

    metrics.num_chunks_retrieved = len(docs_with_scores)
    metrics.update_retrieval_stats([s for _, s in docs_with_scores])

    if not docs_with_scores:
        metrics.total_ms = round((time.perf_counter() - pipeline_start) * 1000, 2)
        return {
            "response": (
                "I don't have enough information in my knowledge base to answer this. "
                "I'll escalate this to a human agent who can assist you further."
            ),
            "sources": [], "confidence": 0.0, "confidence_detail": {},
            "retrieved_context": "", "retrieval_scores": [],
            "no_docs_found": True, "metrics": metrics,
        }

    # 3. Build context
    context_text, sources, scores = _build_context_block(docs_with_scores)

    # 4. Build messages (OpenAI format — converted inside _gemini_call)
    context_prompt = (
        "Use ONLY the following context to answer the customer's question. "
        "If the answer is not fully covered, say so explicitly.\n\n"
        f"=== CONTEXT START ===\n{context_text}\n=== CONTEXT END ===\n\n"
        f"Customer question: {query}"
    )
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(conversation_history)
    messages.append({"role": "user", "content": context_prompt})

    # 5. LLM call
    with timed_stage(metrics, "llm"):
        response_obj = _gemini_call(
            messages, system_instruction=SYSTEM_PROMPT, max_tokens=1024, temperature=0.2
        )

    response_text = response_obj.text.strip()
    pt, ct, tt = _extract_tokens(response_obj)
    metrics.prompt_tokens, metrics.completion_tokens, metrics.total_tokens = pt, ct, tt

    # 6. Confidence scoring
    with timed_stage(metrics, "scoring"):
        conf_detail = score_response_detailed(scores, response_text)

    metrics.confidence_score = conf_detail["score"]
    metrics.total_ms = round((time.perf_counter() - pipeline_start) * 1000, 2)
    metrics.log_summary(logger)

    return {
        "response": response_text,
        "sources": sources,
        "confidence": conf_detail["score"],
        "confidence_detail": conf_detail,
        "retrieved_context": context_text,
        "retrieval_scores": scores,
        "no_docs_found": False,
        "metrics": metrics,
    }


def generate_response_no_docs(
    query: str,
    conversation_history: list[dict],
    metrics: Optional[PipelineMetrics] = None,
) -> dict:
    """Fallback when no knowledge base is loaded."""
    if metrics is None:
        metrics = PipelineMetrics()
    start = time.perf_counter()

    system = (
        "You are a customer support assistant. No knowledge base has been loaded yet. "
        "Politely let the customer know that the support team has not yet uploaded any "
        "documents, and advise them to try again later or contact support directly. "
        "Do NOT answer from general knowledge."
    )
    messages = [{"role": "system", "content": system}]
    messages.extend(conversation_history)
    messages.append({"role": "user", "content": query})

    with timed_stage(metrics, "llm"):
        response_obj = _gemini_call(messages, system_instruction=system,
                                    max_tokens=300, temperature=0.1)

    pt, ct, tt = _extract_tokens(response_obj)
    metrics.prompt_tokens, metrics.completion_tokens, metrics.total_tokens = pt, ct, tt
    metrics.total_ms = round((time.perf_counter() - start) * 1000, 2)

    return {
        "response": response_obj.text.strip(),
        "sources": [], "confidence": 0.0, "confidence_detail": {},
        "retrieved_context": "", "retrieval_scores": [],
        "no_docs_found": True, "metrics": metrics,
    }
