"""
Observability module — structured logging, pipeline timing, and metrics.

Provides:
  - JSON-formatted structured logger (writes to stdout + rotating log file)
  - PipelineMetrics dataclass to capture timings, tokens, and quality signals
  - timed_stage() context manager to measure each pipeline step
  - get_perf_stats() to aggregate metrics from the SQLite log for dashboards
"""
import json
import logging
import logging.handlers
import sys
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Generator, Optional

from src.config import LOG_FILE


# ---------------------------------------------------------------------------
# Structured JSON formatter
# ---------------------------------------------------------------------------
class _JSONFormatter(logging.Formatter):
    """Emit each log record as a single JSON line for easy parsing."""

    def format(self, record: logging.LogRecord) -> str:
        entry: dict = {
            "ts": datetime.utcnow().isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # Merge any extra fields added via logger.info("...", extra={...})
        for key, val in record.__dict__.items():
            if key not in (
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "exc_info", "exc_text", "stack_info",
                "lineno", "funcName", "created", "msecs", "relativeCreated",
                "thread", "threadName", "processName", "process", "message",
            ):
                entry[key] = val

        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(entry, default=str)


def get_logger(name: str = "support_system") -> logging.Logger:
    """
    Return a logger that writes structured JSON to stdout and to a rotating
    file at LOG_FILE (max 5 MB, 3 backups).
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    # Stdout handler — INFO and above
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.INFO)
    stdout_handler.setFormatter(_JSONFormatter())
    logger.addHandler(stdout_handler)

    # Rotating file handler — DEBUG and above
    try:
        import os
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(_JSONFormatter())
        logger.addHandler(file_handler)
    except Exception:
        pass  # If log file can't be created, stdout-only is fine

    logger.propagate = False
    return logger


# ---------------------------------------------------------------------------
# PipelineMetrics dataclass
# ---------------------------------------------------------------------------
@dataclass
class PipelineMetrics:
    """Captures all observable signals for a single query-response cycle."""

    request_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    session_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    # ---- Pipeline stage timings (milliseconds) ----
    classification_ms: float = 0.0
    expansion_ms: float = 0.0
    retrieval_ms: float = 0.0
    llm_ms: float = 0.0
    scoring_ms: float = 0.0
    total_ms: float = 0.0

    # ---- Token usage ----
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    # ---- Retrieval quality ----
    num_chunks_retrieved: int = 0
    num_chunks_after_filter: int = 0
    avg_retrieval_score: float = 0.0
    max_retrieval_score: float = 0.0
    min_retrieval_score: float = 0.0
    query_expanded: bool = False

    # ---- Output quality ----
    confidence_score: float = 0.0
    confidence_breakdown: dict = field(default_factory=dict)
    escalated: bool = False
    severity: Optional[str] = None
    priority: Optional[int] = None

    # ---- Error tracking ----
    errors: list = field(default_factory=list)

    def update_retrieval_stats(self, scores: list[float]) -> None:
        """Populate retrieval quality fields from a list of scores."""
        self.num_chunks_after_filter = len(scores)
        if scores:
            self.avg_retrieval_score = round(sum(scores) / len(scores), 4)
            self.max_retrieval_score = round(max(scores), 4)
            self.min_retrieval_score = round(min(scores), 4)

    def to_dict(self) -> dict:
        return asdict(self)

    def log_summary(self, logger: logging.Logger) -> None:
        """Emit a single structured log line summarising the pipeline run."""
        logger.info(
            "pipeline_complete",
            extra={
                "request_id": self.request_id,
                "session_id": self.session_id[:8] if self.session_id else "",
                "total_ms": self.total_ms,
                "retrieval_ms": self.retrieval_ms,
                "llm_ms": self.llm_ms,
                "total_tokens": self.total_tokens,
                "confidence": self.confidence_score,
                "chunks": self.num_chunks_after_filter,
                "escalated": self.escalated,
                "severity": self.severity,
                "errors": len(self.errors),
            },
        )


# ---------------------------------------------------------------------------
# timed_stage context manager
# ---------------------------------------------------------------------------
@contextmanager
def timed_stage(
    metrics: PipelineMetrics, stage: str
) -> Generator[None, None, None]:
    """
    Measure elapsed time for a pipeline stage and store it in the metrics
    object under the attribute f"{stage}_ms".

    Usage:
        with timed_stage(metrics, "retrieval"):
            docs = search(query)
    """
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed_ms = (time.perf_counter() - start) * 1000
        attr = f"{stage}_ms"
        if hasattr(metrics, attr):
            setattr(metrics, attr, round(elapsed_ms, 2))


# ---------------------------------------------------------------------------
# Aggregate perf stats from the SQLite log
# ---------------------------------------------------------------------------
def get_perf_stats() -> dict:
    """
    Read aggregate performance metrics from the interactions table.
    Returns a dict suitable for the observability dashboard.
    """
    from src.config import DB_PATH
    import sqlite3

    try:
        conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        conn.row_factory = sqlite3.Row

        stats = {}

        # Latency percentiles
        rows = conn.execute(
            "SELECT total_latency_ms FROM interactions WHERE total_latency_ms > 0 ORDER BY id DESC LIMIT 200"
        ).fetchall()
        latencies = [r[0] for r in rows if r[0]]
        if latencies:
            latencies.sort()
            n = len(latencies)
            stats["p50_ms"] = latencies[n // 2]
            stats["p95_ms"] = latencies[int(n * 0.95)]
            stats["p99_ms"] = latencies[int(n * 0.99)] if n >= 100 else latencies[-1]
            stats["avg_ms"] = round(sum(latencies) / n, 1)
        else:
            stats["p50_ms"] = stats["p95_ms"] = stats["p99_ms"] = stats["avg_ms"] = 0

        # Token usage
        token_rows = conn.execute(
            "SELECT SUM(prompt_tokens), SUM(completion_tokens), AVG(total_tokens) "
            "FROM interactions WHERE total_tokens > 0"
        ).fetchone()
        stats["total_prompt_tokens"] = int(token_rows[0] or 0)
        stats["total_completion_tokens"] = int(token_rows[1] or 0)
        stats["avg_tokens_per_query"] = round(token_rows[2] or 0, 1)

        # Confidence distribution
        for band, lo, hi in [("high", 0.80, 1.01), ("medium", 0.50, 0.80), ("low", 0.0, 0.50)]:
            count = conn.execute(
                "SELECT COUNT(*) FROM interactions WHERE confidence_score >= ? AND confidence_score < ?",
                (lo, hi),
            ).fetchone()[0]
            stats[f"conf_{band}"] = count

        # Escalation rate over last 50 interactions
        recent = conn.execute(
            "SELECT escalated FROM interactions ORDER BY id DESC LIMIT 50"
        ).fetchall()
        if recent:
            stats["recent_escalation_rate"] = round(
                sum(1 for r in recent if r[0]) / len(recent), 3
            )
        else:
            stats["recent_escalation_rate"] = 0.0

        # Avg chunks retrieved
        chunk_avg = conn.execute(
            "SELECT AVG(num_chunks) FROM interactions WHERE num_chunks > 0"
        ).fetchone()[0]
        stats["avg_chunks"] = round(chunk_avg or 0, 1)

        conn.close()
        return stats

    except Exception:
        return {}
