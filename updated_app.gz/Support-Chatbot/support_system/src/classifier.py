"""
Query classification module — powered by Google Gemini 1.5 Flash (google-genai SDK).

One LLM call classifies the query AND detects off-topic intent simultaneously.

Edge cases handled WITHOUT an LLM call (rule-based, zero latency):
  - Pure greetings ("hi", "hello") → is_greeting=True
  - Single-character / symbol queries → is_too_short=True
"""
import json
import logging
import time

from google import genai
from google.genai import types

from src.config import CHAT_MODEL, GEMINI_API_KEY, MAX_QUERY_LENGTH, SENSITIVE_CATEGORIES

_log = logging.getLogger(__name__)

CATEGORIES = [
    "General", "Technical", "Billing", "Account",
    "Complaint", "Legal", "Security", "Other",
]

# ---------------------------------------------------------------------------
# Rule-based pre-checks (no LLM call)
# ---------------------------------------------------------------------------

_GREETING_WORDS: frozenset = frozenset([
    "hi", "hello", "hey", "hiya", "howdy", "sup", "yo",
    "good morning", "good afternoon", "good evening", "good day",
    "greetings", "what's up", "whats up", "morning", "evening", "afternoon",
])

_GREETING_RESPONSE: str = (
    "Hi there! I'm your customer support assistant.\n\n"
    "Here are some things I can help you with:\n"
    "- 📦 Orders, shipping, and returns\n"
    "- 💳 Billing, payments, and subscriptions\n"
    "- 🔧 Technical issues and troubleshooting\n"
    "- 👤 Account access and settings\n"
    "- 📜 Policies, warranties, and terms\n\n"
    "What can I help you with today?"
)

_REDIRECT_TEMPLATE = (
    "That's a bit outside what I can help with — I'm a customer support "
    "assistant focused on questions about our products and services.\n\n"
    "Here are some things I **can** help you with:\n"
    "- 📦 Orders, shipping, and returns\n"
    "- 💳 Billing, payments, and subscriptions\n"
    "- 🔧 Technical issues and troubleshooting\n"
    "- 👤 Account access and settings\n"
    "- 📜 Policies, warranties, and terms\n\n"
    "Feel free to ask me anything along those lines!"
)

_REDIRECT_TEMPLATE_REPEATED = (
    "I've noticed a few questions that fall outside what I can help with here. "
    "I'm only set up to assist with questions about our products and services.\n\n"
    "If you're having trouble or need general assistance, "
    "a human agent would be happy to help you directly. I'm flagging this for the team now."
)

_CLARIFY_RESPONSE: str = (
    "I didn't quite catch that — could you describe what you need help with? "
    "I'm here to assist with orders, billing, account issues, and technical problems."
)

# ---------------------------------------------------------------------------
# Classification prompt
# ---------------------------------------------------------------------------

_CLASSIFICATION_PROMPT = """You are a classifier for a customer support chat system.

Analyse the following customer query and return a JSON object with these exact fields:

1. "category": EXACTLY ONE of these: {categories}
   Use "Other" only for real support queries that don't fit other categories.

2. "is_sensitive": true if the query involves legal threats, fraud, account breaches,
   or strong emotional distress. Otherwise false.

3. "is_off_topic": true ONLY if the query has NOTHING to do with customer support,
   products, services, accounts, orders, billing, or company policies.
   Examples OFF-TOPIC: "what is 2+2", "tell me a joke", "who is the president"
   Examples ON-TOPIC: "my order hasn't arrived", "how do I reset my password", "I want a refund"
   When in doubt, classify as ON-TOPIC.

4. "reasoning": one sentence explaining your classification.

Return ONLY valid JSON — no markdown fences, no extra text.

Query: {query}"""


def _is_pure_greeting(query: str) -> bool:
    normalized = query.lower().strip().rstrip("!.,?").strip()
    return normalized in _GREETING_WORDS


def _is_too_short(query: str) -> bool:
    return len(query.strip()) < 2


def _safe_json(raw: str) -> dict | None:
    raw = raw.strip()
    if raw.startswith("```"):
        for part in raw.split("```"):
            part = part.strip().lstrip("json").strip()
            if part.startswith("{"):
                raw = part
                break
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(raw[start:end])
            except json.JSONDecodeError:
                pass
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def classify_query(query: str) -> dict:
    """Classify a customer query. Returns a classification dict."""
    _base = {
        "is_sensitive": False, "is_off_topic": False,
        "is_greeting": False, "is_too_short": False, "redirect_msg": "",
    }

    if _is_pure_greeting(query):
        return {**_base, "category": "General", "is_greeting": True,
                "reasoning": "Pure greeting detected."}

    if _is_too_short(query):
        return {**_base, "category": "General", "is_too_short": True,
                "reasoning": "Query too short to classify."}

    truncated = query[:MAX_QUERY_LENGTH]
    prompt = _CLASSIFICATION_PROMPT.format(
        categories=", ".join(CATEGORIES),
        query=truncated,
    )

    client = genai.Client(api_key=GEMINI_API_KEY)

    for attempt in range(1, 4):
        try:
            response = client.models.generate_content(
                model=CHAT_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0,
                    max_output_tokens=220,
                ),
            )
            result = _safe_json(response.text)
            if result is None:
                raise ValueError(f"Could not parse JSON: {response.text[:200]}")

            if result.get("category") not in CATEGORIES:
                result["category"] = "Other"
            if result["category"] in SENSITIVE_CATEGORIES:
                result["is_sensitive"] = True

            result.setdefault("is_off_topic", False)
            result.setdefault("is_sensitive", False)
            result["is_greeting"] = False
            result["is_too_short"] = False
            result["redirect_msg"] = ""
            return result

        except Exception as exc:
            _log.warning("classify_query attempt %d failed: %s", attempt, exc)
            if attempt < 3:
                time.sleep(1.5 * attempt)

    _log.error("classify_query failed after 3 attempts — defaulting to on-topic")
    return {**_base, "category": "Other",
            "reasoning": "Classification unavailable — defaulting to on-topic."}


def get_redirect_message(streak: int) -> str:
    return _REDIRECT_TEMPLATE_REPEATED if streak >= 2 else _REDIRECT_TEMPLATE


def get_greeting_response() -> str:
    return _GREETING_RESPONSE


def get_clarify_response() -> str:
    return _CLARIFY_RESPONSE
