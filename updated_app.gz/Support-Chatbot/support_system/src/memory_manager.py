"""
Conversation memory manager.

Maintains a sliding window of recent message turns so the LLM can
refer to earlier context within a session.  Each turn is stored as a
plain dict {role, content} compatible with the OpenAI chat format.
"""

# Maximum number of turns (user + assistant pairs) to keep in the window
MAX_TURNS: int = 10


def init_history() -> list[dict]:
    """Return a fresh, empty conversation history list."""
    return []


def add_turn(history: list[dict], user_message: str, assistant_message: str) -> list[dict]:
    """
    Append a user/assistant exchange to the history and enforce the window
    size by dropping the oldest turns first.
    """
    history.append({"role": "user", "content": user_message})
    history.append({"role": "assistant", "content": assistant_message})

    # Each turn = 2 messages; trim to keep the most recent MAX_TURNS turns
    max_messages = MAX_TURNS * 2
    if len(history) > max_messages:
        history = history[-max_messages:]

    return history


def format_for_prompt(history: list[dict]) -> list[dict]:
    """
    Return the history in a format ready to prepend to the LLM messages list.
    Strips out any keys beyond role/content for safety.
    """
    return [{"role": m["role"], "content": m["content"]} for m in history]


def clear_history() -> list[dict]:
    """Return a fresh empty history (call this on 'New conversation')."""
    return []


def summarise_history(history: list[dict]) -> str:
    """
    Return a plain-text summary of the conversation so far, useful for
    displaying in the sidebar or logs.
    """
    if not history:
        return "No conversation yet."

    lines = []
    for msg in history:
        prefix = "User" if msg["role"] == "user" else "Agent"
        snippet = msg["content"][:120].replace("\n", " ")
        lines.append(f"**{prefix}:** {snippet}…" if len(msg["content"]) > 120 else f"**{prefix}:** {snippet}")
    return "\n\n".join(lines)
