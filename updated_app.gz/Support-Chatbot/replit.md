# AI-Powered Customer Support Workflow System

A production-style AI customer support system that answers L1 queries using RAG over company documents, escalates uncertain or sensitive queries to human agents, and maintains a full audit trail.

## Run & Operate

- `cd support_system && streamlit run app.py --server.port 5000` — run the Streamlit app
- Workflow name: **AI Support System** (already configured)
- Required env: `OPENAI_API_KEY` — your OpenAI API key

## Stack

- Python 3.11, Streamlit 1.57
- LLM: OpenAI `gpt-4o-mini` (chat) + `text-embedding-3-small` (embeddings)
- RAG: LangChain + FAISS (disk-persisted vector index)
- Document loading: PyPDFLoader (PDF), TextLoader (TXT/MD)
- Logging: SQLite (interactions + escalations)
- All settings: `support_system/src/config.py`

## Where things live

- `support_system/app.py` — Main chat page
- `support_system/pages/` — Documents, Escalations, Logs pages
- `support_system/src/` — All business logic modules
- `support_system/data/vector_store/` — Persisted FAISS index
- `support_system/data/interactions.db` — SQLite audit log
- `support_system/ARCHITECTURE.md` — Full architecture diagram
- `support_system/WORKFLOW.md` — Step-by-step workflow explanation
- `support_system/DEMO_SCRIPT.md` — 15-minute demo walkthrough
- `support_system/README.md` — Setup and usage guide

## Architecture decisions

- **RAG over fine-tuning** — documents can be updated without retraining; every answer is traceable to a source chunk
- **Rank-weighted confidence scoring** — top retrieved chunk weighted 1.0, second 0.5, etc.; coverage penalty if LLM signals uncertainty
- **Four escalation triggers** — confidence threshold, sensitive category, sensitive keywords, explicit human request; any one fires escalation
- **Sliding-window memory** — last 10 turns (20 messages) prepended to every LLM call; keeps token usage bounded
- **SQLite for persistence** — zero-dependency, file-backed; swap to Postgres for production scale

## Product

- Chat interface with real-time RAG responses, confidence badges, and source citations
- Document upload (PDF/TXT/MD) → automatic chunking and FAISS indexing
- Escalation queue for human agents with status tracking and notes
- Full interaction audit log with filter, CSV export, and deep-dive inspection
- Configurable confidence threshold slider (no restart needed)
- 👍/👎 feedback buttons on every response

## User preferences

- Python backend + Streamlit frontend
- OpenAI API (gpt-4o-mini + text-embedding-3-small)
- LangChain + FAISS vector database
- Modular codebase with clear comments
- Include architecture diagram, workflow explanation, and demo script

## Gotchas

- Always run from `support_system/` directory so `src/` imports resolve correctly
- FAISS index must be re-built if you change the embedding model
- Scanned PDFs (image-only) won't extract text — need OCR preprocessing
- `langchain.schema` is deprecated → use `langchain_core.documents`
- `langchain.text_splitter` → use `langchain_text_splitters`
